class CoffeeMachine():
    def __init__(self, water, milk, coffee, money):
        self.resources = {
            "water": water,
            "milk": milk,
            "coffee": coffee,
            "money": money
        }

        self.menu = {
            "espresso": {
                "ingredients": {
                    "water": 50,
                    "milk": 0,
                    "coffee": 18,
                },
                "cost": 1.5,
            },
            "latte": {
                "ingredients": {
                    "water": 200,
                    "milk": 150,
                    "coffee": 24,
                },
                "cost": 2.5,
            },
            "cappuccino": {
                "ingredients": {
                    "water": 250,
                    "milk": 100,
                    "coffee": 24,
                },
                "cost": 3.0,
            }    
        }
    
    def check_money(self, quarters, dimes, nickles, pennies, choice):
        if (quarters * 0.25 + dimes * 0.1 + nickles * 0.05 + pennies * 0.01 > self.menu[choice]["cost"]):
            return True
        else:
            return False

    def calc_missing_money(self, quarters, dimes, nickles, pennies, choice):
        return round(self.menu[choice]["cost"] - quarters * 0.25 + dimes * 0.1 + nickles * 0.05 + pennies * 0.01, 2)

    def calc_missing_resources(self, choice):
        missing = ""
        if (self.menu[choice]["ingredients"]["water"] > self.resources["water"]):
            missing += "water: " + str(self.menu[choice]["ingredients"]["water"] - self.resources["water"]) + ", "
        if (self.menu[choice]["ingredients"]["milk"] > self.resources["milk"]):
            missing += "milk: " + str(self.menu[choice]["ingredients"]["milk"] - self.resources["milk"]) + ", "
        if (self.menu[choice]["ingredients"]["coffee"] > self.resources["coffee"]):
            missing += "coffee: " + str(self.menu[choice]["ingredients"]["coffee"] - self.resources["coffee"]) + ", "
        missing = missing[:-2]
        missing += '.'
        return missing
        
    def calc_change(self, quarters, dimes, nickles, pennies, choice):
        return quarters * 0.25 + dimes * 0.1 + nickles * 0.05 + pennies * 0.01 - self.menu[choice]["cost"]
    
    def check_resources(self, choice):
        if (
            self.resources["water"] >= self.menu[choice]["ingredients"]["water"] and
            self.resources["milk"] >= self.menu[choice]["ingredients"]["milk"] and
            self.resources["coffee"] >= self.menu[choice]["ingredients"]["coffee"]
        ):
            return True
        else:
            return False

    def deplete_resources(self, choice):
        self.resources["water"] -= self.menu[choice]["ingredients"]["water"]
        self.resources["milk"] -= self.menu[choice]["ingredients"]["milk"]
        self.resources["coffee"] -= self.menu[choice]["ingredients"]["coffee"]
    
    def add_coins(self, quarters, dimes, nickles, pennies, choice):
        self.resources['money'] += self.menu[choice]['cost']

    def print_report(self):
        print(f"Water: {self.resources['water']}ml\nMilk: {self.resources['milk']}ml\nCoffee: {self.resources['coffee']}g\nMoney: ${self.resources['money']}")

    def refill_resources(self, water, milk, coffee):
        self.resources["water"] += water
        self.resources["milk"] += milk
        self.resources["coffee"] += coffee
        print("Finished filling resources!")
    
cm1 = CoffeeMachine(300, 200, 100, 0)

finished = False
while (finished == False):
    choice = input("What would you like? (espresso / latte / cappuccino): ").lower()
    if (choice == "espresso" or choice == "latte" or choice == "cappuccino"):
        print("Please insert coins.")
        quarters = int(input("How many quarters?: "))
        dimes = int(input("How many dimes?: "))
        nickles = int(input("How many nickles?: "))
        pennies = int(input("How many pennies?: "))
        suff_money = cm1.check_money(quarters, dimes, nickles, pennies, choice)
        if (suff_money == True):
            suff_resources = cm1.check_resources(choice)
            if (suff_resources == True):
                cm1.deplete_resources(choice)
                cm1.add_coins(quarters, dimes, nickles, pennies, choice)
                print(f"Here is ${cm1.calc_change(quarters, dimes, nickles, pennies, choice)} in change.")
                print(f"Here is your {choice} ☕. Enjoy!")
            else:
                #print("suff_resources" + str(suff_resources))
                print(f"You are missing {cm1.calc_missing_resources(choice)}")
        else:
            print(f"You are missing ~${cm1.calc_missing_money(quarters, dimes, nickles, pennies, choice)}")
    elif (choice == "report"): # print report
        cm1.print_report()
    elif (choice == "refill"): # refill resources
        water = int(input("Enter amount of water: "))
        milk = int(input("Enter amount of milk: "))
        coffee = int(input("Enter amount of coffee: "))
        cm1.refill_resources(water, milk, coffee)
    elif (choice == "off"):
        finished = True
        print("Have a nice day.")
    else:
        print("Sorry. Your decision wasn't clear.")
