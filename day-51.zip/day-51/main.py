from selenium import webdriver
from selenium.webdriver.common.by import By
import time

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys


driver = webdriver.Chrome()

driver.get("https://www.speedtest.net/")
driver.maximize_window()
time.sleep(10)

go_button = driver.find_element(By.XPATH, "//span[text()='Go']")
go_button.click()
time.sleep(85)

download_speed = driver.find_element(By.XPATH, "//span[@class='result-data-large number result-data-value download-speed']")
upload_speed = driver.find_element(By.XPATH, "//span[@class='result-data-large number result-data-value download-speed']")

actual_download_speed = download_speed.text
actual_upload_speed = upload_speed.text

driver.get("https://twitter.com/login")
time.sleep(10)

#sign_in_button = driver.find_element(By.XPATH, "//span[text()='Sign in']/../..")
#sign_in_button.click()
#time.sleep(10)

email_field = driver.find_element(By.XPATH, "//input[@name='text']")
email_field.send_keys("johnmckay1229@gmail.com")
next_button = driver.find_element(By.XPATH, "//span[text()='Next']/../..")
next_button.click()
time.sleep(3)

try:
    unusual_login_field = driver.find_element(By.XPATH, "//input[@name='text']")
    unusual_login_field.send_keys("@John57169466960")
    next_button = driver.find_element(By.XPATH, "(//div[@role='button'])[2]")
    next_button.click()
    time.sleep(3)
except:
    pass

password_field = driver.find_element(By.XPATH, "//input[@name='password']")
password_field.send_keys("zxcasdqwe123631029x")
time.sleep(1)

log_in_button = driver.find_element(By.XPATH, "//span[text()='Log in']/../..")
log_in_button.click()
time.sleep(10)

message = f"Hello InternetProvider, my internet download speed is: {actual_download_speed} and the upload speed is: {actual_upload_speed}. Please fix this."
post_text_box = driver.find_element(By.XPATH, "//div[@role='textbox']//div//div//div")
post_button = driver.find_element(By.XPATH, "//span[text()='Post']/..")

post_text_box.send_keys(message)
post_button.click()
time.sleep(5)

try:
    #close_button = driver.find_element(By.XPATH, "//div[@aria-label='Close']")
    #close_button.click()
    #time.sleep(5)
    post_text_box = driver.find_element(By.XPATH, "//div[@role='textbox']//div//div//div")
    post_button = driver.find_element(By.XPATH, "(//span[text()='Post'])[1]")
    post_text_box.send_keys(message)
    time.sleep(10000000000)
    post_button.click()
except:
    pass

#post_text_box.click()
#post_text_box.send_keys(message)
post_button.click()
time.sleep(5)

driver.quit()
