from turtle import Turtle, Screen
from snake import Snake
from food import Food
from wall import Wall

# Define the window
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

s1 = Snake()
f1 = Food()
w1 = Wall()

screen.listen()
screen.onkey(key="d", fun=s1.turn_east)
screen.onkey(key="w", fun=s1.turn_north)
screen.onkey(key="a", fun=s1.turn_west)
screen.onkey(key="s", fun=s1.turn_south)

game_over = False
while (game_over == False):
    s1.move()
    game_over = s1.check_body_crash()
    if (game_over == True):
        break
    eaten = f1.check_food_eaten(s1.body[0].pos()[0], s1.body[0].pos()[1])
    if (eaten == True):
        s1.grow_by_one()
    game_over = w1.check_crash_wall(s1.body[0].pos()[0], s1.body[0].pos()[1])
    if (game_over == True):
        break

print("GAME OVER")
