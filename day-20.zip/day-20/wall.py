from turtle import Turtle, Screen
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

class Wall():
    def __init__(self):
        self.wall = Turtle()
        self.wall.hideturtle()
        self.wall.shape("square")
        self.wall.color("red")
        self.wall.pensize(20)
        self.wall.penup()
        self.create_wall()

    def create_wall(self):
        screen.tracer(0)
        self.wall.setpos(-372, 311)
        self.wall.pendown()
        self.wall.forward(736)
        self.wall.right(90)
        self.wall.forward(614)
        self.wall.right(90)
        self.wall.forward(736)
        self.wall.right(90)
        self.wall.forward(614)
        screen.tracer(1)
    
    def check_crash_wall(self, head_pos_x, head_pos_y):
        if (
            head_pos_x >= 334 or
            head_pos_x <= -322 or
            head_pos_y >= 271 or
            head_pos_y <= -273
        ):
            return True # game_over = True
        else:
            return False # game_over = False


#w1 = Wall()

#self.food.setpos(-372, 311)
#self.food.setpos(364, 311)
#self.food.setpos(364, -303)
#self.food.setpos(-372, -303)
