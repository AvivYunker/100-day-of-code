import colorgram
from turtle import Turtle, Screen
import turtle as t
import random

ten_colors = colorgram.extract("kirby_yarn_colors.PNG", 10)

colors = []

for extracted in ten_colors:
    colors.append((extracted.rgb[0], extracted.rgb[1], extracted.rgb[2]))

#for color in colors:
#    print(color)

t.colormode(255)

t1 = Turtle()
t1.shape("circle")
t1.pensize(10)
t1.speed(5)
t1.penup()
t1.setpos((-250, -250))

for cnt1 in range(0, 10, 1):
    for cnt2 in range(0, 10, 1):
        t1.pencolor(random.choice(colors))
        t1.forward(50)
        t1.dot()
    t1.backward(500)
    t1.left(90)
    t1.forward(50)
    t1.right(90)

t1.hideturtle()

screen = Screen()
screen.exitonclick()
