## Day 99 Course Assignment: Analyse Deaths involving Police in the United States

_Extract insights from combining US census data and the Washington Post's database on deaths by police in the United States_

# Day 99 - Analyzing Deaths Involving Police in the United States

## Concepts Practised
- Removing NaN Values and Duplicates
- Create Pie and Donut Charts
- Grouped Bar Charts and Box Plots with Plotly
- Data Cleaning: Working with Time Stamps

## Deaths Involving Police in the United States
<img width="780" alt="day99(3)" src="https://user-images.githubusercontent.com/98851253/175056706-9ef8e9db-a332-4029-8de8-335e682d9c56.png">
<img width="781" alt="day99(1)" src="https://user-images.githubusercontent.com/98851253/175056709-1962dcc4-02d3-4bb7-a26a-808503808ee0.png">
<img width="796" alt="day99(2)" src="https://user-images.githubusercontent.com/98851253/175056712-e4189734-75f1-48ac-b274-b8af4575a13d.png">
