morse_dict = {
    "A":"○▭",
    "B":"▭○○○",
    "C":"▭○▭○",
    "D":"▭○○",
    "E":"○",
    "F":"○○▭○",
    "G":"▭▭○",
    "H":"○○○○",
    "I":"○○",
    "J":"○▭▭▭",
    "K":"▭○▭",
    "L":"○▭○○",
    "M":"▭▭",
    "N":"▭○",
    "O":"▭▭▭",
    "P":"○▭▭○",
    "Q":"▭▭○▭",
    "R":"○▭○",
    "S":"○○○",
    "T":"▭",
    "U":"○○▭",
    "V":"○○○▭",
    "W":"○▭▭",
    "X":"▭○○▭",
    "Y":"▭○▭▭",
    "Z":"▭▭○○",
    "1":"○▭▭▭▭",
    "2":"○○▭▭▭",
    "3":"○○○▭▭",
    "4":"○○○○▭",
    "5":"○○○○○",
    "6":"▭○○○○",
    "7":"▭▭○○○",
    "8":"▭▭▭○○",
    "9":"▭▭▭▭○",
    "0":"▭▭▭▭▭",
    ".":"○▭○▭○▭",
    ",":"▭▭○○▭▭",
    "?":"○○▭▭○○",
    "/":"▭○○▭○",
}

def check_valid(strr):
    for char in strr:
        if (char not in morse_dict.keys()):
            return False
    return True

def to_morse(strr):
    for char in strr:
        print(f"{char} = [{morse_dict[char]}]")


finished = False
while (finished == False):
    strr = input("Enter a string: ").upper()
    valid = check_valid(strr)
    while (valid == False):
        print("Sorry, the string you've entered is invalid.")
        strr = input("Enter a string: ").upper()
        valid = check_valid(strr)
    results = to_morse(strr)
