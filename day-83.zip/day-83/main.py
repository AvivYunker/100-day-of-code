from PIL import Image, ImageDraw, ImageFont

def add_watermark(input_path, output_path, text, pos):
    photo = Image.open(input_path)

    # make the image editable
    drawing = ImageDraw.Draw(photo)

    black_color = (235, 241, 245)
    font = ImageFont.truetype("Pillow/Tests/fonts/Arial.ttf", 150)
    drawing.text(pos, text, fill = black_color, font = font)
    photo.show()
    photo.save(output_path)


if __name__ == "__main__":
    img = "cat.jpg"
    add_watermark(img, "watermarked.jpg", text="new_pic", pos=(100, 100))
