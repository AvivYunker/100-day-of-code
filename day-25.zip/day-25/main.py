from turtle import Turtle, Screen
import pandas
import tkinter

def place_state_label(answer, states_dict):
    # Turtle.write("GeeksForGeeks", (50,50), font=("Verdana", 15, "normal"))
    #my_label = tkinter.Label(text="I am a label", font=("Arial", 12, "bold"))
    #print("states_dict[answer][0]: " + str(states_dict[answer][0]))
    #print("states_dict[answer][1]: " + str(states_dict[answer][1]))
    #my_label.place(x=300, y=350)
    t.goto(states_dict[answer][0], states_dict[answer][1])
    #t.pendown()
    t.write(answer, align="left", move=True)
    #t.penup()

    #my_label.place(x=states_dict[answer][0]+338, y=states_dict[answer][1]+456)

def check_correct(answer, score, states_dict):
    if (answer in states_dict):
        if (states_dict[answer][2] == False):
            score += 1
            states_dict[answer][2] = True
            place_state_label(answer, states_dict)
        else:
            pass
            #print("NO1")
    else:
        pass
        #print("NO2")
    return score
    

# Game Setup
screen = Screen()
screen.setup(725, 491)
image = "blank_states_img.gif"
screen.register_shape(image)
sprite = Turtle()
sprite.shape(image)

# Turtle Setup
t = Turtle()
t.penup()
t.hideturtle()

# Open CSV with Pandas
data = pandas.read_csv("50_states.csv")
df = pandas.DataFrame(data) # df = "Data Frame"
#print(df)
#print("\n\n")
states_dict = {}
for (index, row) in df.iterrows():
    #print(f"index: {index} / state: {row.state} / x: {row.x} / y: {row.y}")
    states_dict[row.state] = [row.x, row.y, False]
#print(states_dict)

# Game Mechanics
score = int(0)
prompt_text_0 = "Name of state?"
prompt_text_1 = "What's another state name?"
score = 49
while (score < 50):
    answer = screen.textinput(title=f"{score}/{50} States Correct", prompt="What's another state name?")
    screen.tracer(1)
    answer = answer.title()
    score = check_correct(answer, score, states_dict)
if (score == 50):
    answer = screen.textinput(title="Game Over", prompt="You Win!")
else:
    answer = screen.textinput(title="Game Over", prompt="You lose...")
#screen.exitonclick()
