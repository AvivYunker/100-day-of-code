from turtle import Turtle, Screen
from paddle import Paddle
from ball import Ball
from wall import Wall
from lives import Lives
from score import Score
from bricks import Bricks

# Define the window
HEIGHT = 630
WIDTH = 630
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Breakout Game")

# Define the paddle
p1 = Paddle(50, -260)
screen.listen()
screen.onkey(key="Left", fun=p1.go_left)
screen.onkey(key="Right", fun=p1.go_right)

# Define the ball
b1 = Ball()

# Define the walls
top_wall = Wall(0, 332, "top")
right_wall = Wall(385, 0, "right")
bottom_wall = Wall(0, -325, "bottom")
left_wall = Wall(-392, 0, "left")

# Define Lives
l1 = Lives(5, -370, 270)

# Define Score
s1 = Score(120, 270)

# Define the Bricks
br1 = Bricks(-340, 230)
#br1 = Bricks(-370, 230)

game_over = False
while (game_over == False):
    b1.move()
    
    paddle_collision = p1.check_collision(b1.get_x(), b1.get_y())
    if (paddle_collision == True):
        b1.minus_one_bounce()
        continue
    
    top_collision = top_wall.check_collision(b1.get_x(), b1.get_y())
    if (top_collision == True):
        b1.minus_one_bounce()
        #print("top")
        continue
    
    right_collision = right_wall.check_collision(b1.get_x(), b1.get_y())
    if (right_collision == True):
        b1.three_bounce()
        #print("right")
        continue
    
    bottom_collision = bottom_wall.check_collision(b1.get_x(), b1.get_y())
    if (bottom_collision == True):
        #print("bottom")
        l1.decrease_lives()
        b1.regenerate_ball()
        if (l1.get_lives() == 0):
            b1.remove_ball()
            l1.render_game_over_label()
            game_over = True
        continue
    
    left_collision = left_wall.check_collision(b1.get_x(), b1.get_y())
    if (left_collision == True):
        b1.three_bounce()
        #print("left")
        continue
    
    brick_collision = br1.check_collision(b1.get_x(), b1.get_y())
    if (brick_collision != int(-1)):
        s1.increase_score(brick_collision)
        b1.minus_one_bounce()
    

#screen = Screen()
screen.exitonclick()
