from turtle import Turtle, Screen
import random
import time

# Define the window
HEIGHT = 630
WIDTH = 630
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Breakout Game")

class Score():
    def __init__(self, x_pos, y_pos):
        self.turtle = Turtle()
        self.turtle.color("white")
        self.turtle.penup()
        self.turtle.hideturtle()
        self.score = int(0)
        self.text = ""
        self.x_position = x_pos
        self.y_position = y_pos
        self.render_score_label()

    def render_score_label(self):
        screen.tracer(0)
        self.turtle.clear()
        self.text = f"Score: {self.score}"
        self.turtle.goto(self.x_position, self.y_position)
        self.turtle.write(self.text, (60,50), font=("Courier", 30, "bold"))
        screen.tracer(1)
    
    def remove_score_label(self):
        self.turtle.clear()

    def increase_score(self, cnt):
        if (cnt >= 0 and cnt <= 47):
            self.score += 4
        elif (cnt >= 48 and cnt <= 95):
            self.score += 2
        self.render_score_label()

# TRYOUTS:
#s1 = Score(120, 270)

#screen = Screen()
#screen.exitonclick()
