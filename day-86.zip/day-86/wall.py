from turtle import Turtle, Screen

# Define the window
HEIGHT = 630
WIDTH = 630
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Breakout Game")

class Wall():
    def __init__(self, x_pos, y_pos, wall_type):
        self.border = Turtle()
        self.border.shape("square")
        self.border.penup()
        self.border.pensize(5)
        self.border.hideturtle()
        self.border.color("black")
        self.x_position = x_pos
        self.y_position = y_pos
        self.wall_type = wall_type
        self.create_wall()
      
    def create_wall(self):
        screen.tracer(0)
        self.border.setpos(self.x_position, self.y_position)
        self.border.stamp()
        screen.tracer(1)
    
    def check_collision(self, ball_x_pos, ball_y_pos):
        if (
            self.wall_type == "top" and
            abs(self.y_position - ball_y_pos) < 10
        ):
            return True
        elif (
            self.wall_type == "right" and
            abs(self.x_position - ball_x_pos) < 10
        ):
            return True
        elif (
            self.wall_type == "bottom" and
            abs(self.y_position - ball_y_pos) < 10
        ):
            return True
        elif (
            self.wall_type == "left" and
            abs(self.x_position - ball_x_pos) < 10
        ):
            return True

# TRYOUTS:
#top_wall = Wall(0, 332, "top")
#right_wall = Wall(385, 0, "right")
#bottom_wall = Wall(0, -325, "bottom")
#left_wall = Wall(-392, 0, "left")

#screen = Screen()
#screen.exitonclick()
