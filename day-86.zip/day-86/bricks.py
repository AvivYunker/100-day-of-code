from turtle import Turtle, Screen

# Define the window
HEIGHT = 630
WIDTH = 630
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Breakout Game")

class Bricks():
    def __init__(self, x_pos, y_pos):
        self.bricks = []
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.generate_bricks()
    
    def generate_bricks(self):
        screen.tracer(0)
        for cnt1 in range(8):
            for cnt2 in range(10):
                self.bricks.append([])
                for cnt3 in range(3):
                    self.bricks[len(self.bricks)-1].append(Turtle())
                    self.bricks[len(self.bricks)-1][cnt3].setpos(self.x_pos + cnt3 * 20, self.y_pos)
                    self.bricks[len(self.bricks)-1][cnt3].shape("square")
                    if (cnt1 == 0 or cnt1 == 1):
                        self.bricks[len(self.bricks)-1][cnt3].color("red")
                    elif (cnt1 == 2 or cnt1 == 3):
                        self.bricks[len(self.bricks)-1][cnt3].color("orange")
                    elif (cnt1 == 4 or cnt1 == 5):
                        self.bricks[len(self.bricks)-1][cnt3].color("yellow")
                    elif (cnt1 == 6 or cnt1 == 7):
                        self.bricks[len(self.bricks)-1][cnt3].color("green")
                    #self.bricks[len(self.bricks)-1].shapesize(1, 2.5, 2)
                self.x_pos += 70
            self.x_pos = -340
            self.y_pos -= 30
        screen.tracer(1)
    
    def check_collision(self, ball_x_pos, ball_y_pos):
        for cnt1 in range(0, len(self.bricks), 1):
            for cnt2 in range(0, 3, 1):
                if (
                    #print(f"self.bricks[cnt1][cnt2].pos()[0]: {self.bricks[cnt1][cnt2].pos()[0]}")
                    abs(self.bricks[cnt1][cnt2].pos()[1] - ball_y_pos) < 5 and
                    0 < abs(self.bricks[cnt1][cnt2].pos()[1] - ball_y_pos) and
                    abs(self.bricks[cnt1][cnt2].pos()[0] - ball_x_pos) < 5 and
                    0 < abs(self.bricks[cnt1][cnt2].pos()[0] - ball_x_pos)
                ):
                    self.remove_brick(cnt1)
                    return cnt1
        return -1

    def remove_brick(self, cnt):
        screen.tracer(0)
        for cnt1 in range(0, len(self.bricks[cnt]), 1):
            self.bricks[cnt][cnt1].hideturtle()
        screen.tracer(1)
