from turtle import Turtle, Screen

# Define the window
HEIGHT = 630
WIDTH = 630
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Breakout Game")

class Paddle():
    def __init__(self, x_pos, y_pos):
        self.x_position = x_pos
        self.y_position = y_pos
        self.paddle = []
        self.create_paddle()

    def create_paddle(self):
        screen.tracer(0)
        for cnt in range(0, 6, 1):
            self.paddle.append(Turtle())
            self.paddle[cnt].shape("square")
            self.paddle[cnt].color("white")
            self.paddle[cnt].penup()
            self.paddle[cnt].turtlesize(1.2)
            self.paddle[cnt].setpos(self.x_position - 20 * cnt, self.y_position)
        screen.tracer(1)

    def go_left(self):
        screen.tracer(0)
        for part in range(0, len(self.paddle), 1):
            self.paddle[part].setpos(self.paddle[part].pos()[0] - 40, self.paddle[part].pos()[1])
        screen.tracer(1)

    def go_right(self):
        screen.tracer(0)
        for part in range(0, len(self.paddle), 1):
            self.paddle[part].setpos(self.paddle[part].pos()[0] + 40, self.paddle[part].pos()[1])
        screen.tracer(1)

    def check_collision(self, ball_x_pos, ball_y_pos):
        for part in self.paddle:
            if (
                (abs(part.pos()[0] - ball_x_pos) < 15) and
                (abs(part.pos()[1] - ball_y_pos) < 15)
            ):
                return True
        return False



# TRYOUT:
#p1 = Paddle(50, -260)

#screen.listen()
#screen.onkey(key="Left", fun=p1.go_left)
#screen.onkey(key="Right", fun=p1.go_right)

#screen = Screen()
#screen.exitonclick()
