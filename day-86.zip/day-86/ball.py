from turtle import Turtle, Screen
import random
import time

# Define the window
HEIGHT = 630
WIDTH = 630
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Breakout Game")

class Ball():
    def __init__(self):
        self.ball = Turtle()
        self.create_ball()
        self.move()

    def create_ball(self):
        screen.tracer(0)
        self.ball.pensize(3)
        self.ball.penup()
        self.ball.shape("circle")
        self.ball.color("white")
        #self.ball.setheading(random.choice([225, 315]))
        self.ball.setheading(random.choice([225]))
        self.ball.speed(5)
        screen.tracer(1)

    def move(self):
        screen.tracer(0)
        self.ball.forward(5)
        #time.sleep(0.02)
        screen.tracer(1)

    def regenerate_ball(self):
        self.ball.speed(1)
        screen.tracer(0)
        self.ball.setpos(0,-50)
        self.ball.setheading(random.choice([225, 315]))
        screen.tracer(1)

    def get_x(self):
        return int(self.ball.pos()[0])
    
    def get_y(self):
        return int(self.ball.pos()[1])
    
    def minus_one_bounce(self):
        screen.tracer(0)
        self.ball.setheading(self.ball.heading() * -1)
        screen.tracer(1)

    def three_bounce(self):
        screen.tracer(0)
        self.ball.setheading(self.ball.heading() * 3)
        screen.tracer(1)

    def remove_ball(self):
        screen.tracer(0)
        self.ball.hideturtle()
        screen.tracer(1)


# TRYOUT:

#screen.listen()
#screen.onkey(key="Left", fun=bricks.go_left)
#screen.onkey(key="Right", fun=bricks.go_right)

#b1 = Ball()
#while (True):
#    b1.move()
