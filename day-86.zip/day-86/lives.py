from turtle import Turtle, Screen
import random
import time

# Define the window
HEIGHT = 630
WIDTH = 630
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Breakout Game")

class Lives():
    def __init__(self, lives, x_pos, y_pos):
        self.turtle = Turtle()
        self.turtle.color("white")
        self.turtle.penup()
        self.turtle.hideturtle()
        self.lives = lives
        self.text = ""
        self.x_position = x_pos
        self.y_position = y_pos
        self.render_lives_label()
    
    def render_lives_label(self):
        screen.tracer(0)
        self.turtle.clear()
        self.text = f"Lives: {self.lives}"
        self.turtle.goto(self.x_position, self.y_position)
        self.turtle.write(self.text, (60,50), font=("Courier", 30, "bold"))
        screen.tracer(1)
    
    def remove_lives_label(self):
        self.turtle.clear()

    def decrease_lives(self):
        self.lives -= 1
        self.render_lives_label()
    
    def render_game_over_label(self):
        screen.tracer(0)
        #self.turtle.clear()
        self.text = f"GAME OVER"
        self.turtle.goto(-120, -50)
        self.turtle.write(self.text, (60,50), font=("Courier", 30, "bold"))
        screen.tracer(1)

    def get_lives(self):
        return self.lives

# TRYOUT:
#l1 = Lives(5, -370, 270) # should be the right positions for "Lives"
#l1.render_game_over_label()

#screen = Screen()
#screen.exitonclick()
