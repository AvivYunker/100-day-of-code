from bs4 import BeautifulSoup
import requests
import csv

response = requests.get("https://news.ycombinator.com/news", verify=False)
yc_web_page = response.text

soup = BeautifulSoup(yc_web_page, "html.parser")

all_numbers = [] # V
all_headers = [] # V
all_sites = []
all_points = []
all_bys = []

headers = soup.find_all(rel="noreferrer")
numbers = soup.find_all(name="span", class_="rank")
sites = soup.find_all(name="span", class_="sitestr")
points = soup.find_all(name="span", class_="score")
bys = soup.find_all(name="a", class_="hnuser")

#article_text = a_tags[0].getText()
#article_link = a_tags[0].get("href")
#article_upvote = soup.find_all(name="span", class_="score")

for number in numbers:
    all_numbers.append(number.text.strip('.'))

for header in headers:
    all_headers.append(header.text)

for site in sites:
    all_sites.append(site.text)

for point in points:
    all_points.append(point.text[0:point.text.index('p')-1])

for by in bys:
    all_bys.append(by.text)

with open("results.csv", 'w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Number", "Headers", "Sites", "Points", "By"])
    for cnt in range(0, len(all_numbers), 1):
        writer.writerow([all_numbers[cnt], all_headers[cnt], all_sites[cnt], all_points[cnt], all_bys[cnt]])
