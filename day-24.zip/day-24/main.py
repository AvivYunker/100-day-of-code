#TODO: Create a letter using starting_letter.txt 
#for each name in invited_names.txt
#Replace the [name] placeholder with the actual name.
#Save the letters in the folder "ReadyToSend".
    
#Hint1: This method will help you: https://www.w3schools.com/python/ref_file_readlines.asp
    #Hint2: This method will also help you: https://www.w3schools.com/python/ref_string_replace.asp
        #Hint3: THis method will help you: https://www.w3schools.com/python/ref_string_strip.asp

names = []


# WORKS
with open("Input\\Names\\invited_names.txt") as InvitedNamesFile:
    contents = InvitedNamesFile.readlines()
    # print(contents)
    for name in contents:
        names.append(name.strip())
    InvitedNamesFile.close()

# WORKS
with open("Input\\Letters\\starting_letter.txt") as StartingLetterFile:
    starting_letter = StartingLetterFile.readlines()
    StartingLetterFile.close()


for name in names:
    custom_message = starting_letter
    custom_message[0] = f'Dear {name},\n'
    for line in custom_message:
        if (line == '\n'):
            custom_message.remove(line)
    custom_message = "\n".join(custom_message)
    #print(custom_message)
    with open(f"Output\\ReadyToSend\\letter_for_{name}.txt", 'w') as custom_file:
        custom_file.write(custom_message)
        custom_file.close()
print("\nDONE!\n")
