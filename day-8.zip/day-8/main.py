logo = """           
 ,adPPYba, ,adPPYYba,  ,adPPYba, ,adPPYba, ,adPPYYba, 8b,dPPYba,  
a8"     "" ""     `Y8 a8P_____88 I8[    "" ""     `Y8 88P'   "Y8  
8b         ,adPPPPP88 8PP"""""""  `"Y8ba,  ,adPPPPP88 88          
"8a,   ,aa 88,    ,88 "8b,   ,aa aa    ]8I 88,    ,88 88          
 `"Ybbd8"' `"8bbdP"Y8  `"Ybbd8"' `"YbbdP"' `"8bbdP"Y8 88   
            88             88                                 
           ""             88                                 
                          88                                 
 ,adPPYba, 88 8b,dPPYba,  88,dPPYba,   ,adPPYba, 8b,dPPYba,  
a8"     "" 88 88P'    "8a 88P'    "8a a8P_____88 88P'   "Y8  
8b         88 88       d8 88       88 8PP""""""" 88          
"8a,   ,aa 88 88b,   ,a8" 88       88 "8b,   ,aa 88          
 `"Ybbd8"' 88 88`YbbdP"'  88       88  `"Ybbd8"' 88          
              88                                             
              88           
"""

alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

def encrypt(text, shift):
    results = ""
    for cnt in range(0, len(text), 1):
        if (text[cnt] not in alphabet):
            results += text[cnt]
        elif (alphabet.index(text[cnt]) + shift > len(alphabet)):
            results += alphabet[alphabet.index(text[cnt]) + shift - len(alphabet)]
        else:
            results += alphabet[alphabet.index(text[cnt]) + shift]
    return results

def decrypt(text, shift):
    results = ""
    for cnt in range(0, len(text), 1):
        if (text[cnt] not in alphabet):
            results += text[cnt]
        elif (alphabet.index(text[cnt]) - shift < 0):
            results += alphabet[alphabet.index(text[cnt]) - shift + len(alphabet)]
        else:
            results += alphabet[alphabet.index(text[cnt]) - shift]
    return results

finish = False
while (finish == False):
    direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n")
    text = input("Type your message:\n").lower()
    shift = int(input("Type the shift number:\n"))
    if (direction == "encode"):
        results = encrypt(text, shift)
    elif (direction == "decode"):
        results = decrypt(text, shift)
    print(f"Here's the {direction}d result: {results}")
    finish = input("Type 'yes' if you want to go again. Otherwise type 'no'. ").lower()
    while (finish != 'yes' and finish != 'no'):
        print("Sorry, your decision was not clear")
        finish = input("Type 'yes' if you want to go again. Otherwise type 'no'. ").lower()
    if (finish == 'yes'):
        finish = False
    elif (finish == 'no'):
        finish = True

#TODO-1: Create a function called 'encrypt' that takes the 'text' and 'shift' as inputs.

    #TODO-2: Inside the 'encrypt' function, shift each letter of the 'text' forwards in the alphabet by the shift amount and print the encrypted text.  
    #e.g. 
    #plain_text = "hello"
    #shift = 5
    #cipher_text = "mjqqt"
    #print output: "The encoded text is mjqqt"

    ##HINT: How do you get the index of an item in a list:
    #https://stackoverflow.com/questions/176918/finding-the-index-of-an-item-in-a-list

    ##🐛Bug alert: What happens if you try to encode the word 'civilization'?🐛

#TODO-3: Call the encrypt function and pass in the user inputs. You should be able to test the code and encrypt a message.
