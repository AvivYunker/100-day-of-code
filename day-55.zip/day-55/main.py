from flask import Flask
import random
app = Flask(__name__)

rndm = random.randrange(0, 10)

@app.route('/')
def root():
    return "<h1> Guess a number between 0 and 9</h1>" \
           '<img width="250px" height="250px" src="https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExdGI1ZzN5MTc4c2pzMzMydHI4YW50d3E2emFlamY1Y2FiejhjczZwMiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3o7aCSPqXE5C6T8tBC/giphy.gif">'

@app.route('/<number>')
def guess(number):
    if (int(number) == int(rndm)):
        return f"<h1 style='color:green'>You found me!</h1>" \
                "<img src='https://media.giphy.com/media/4T7e4DmcrP9du/giphy.gif'>"
    elif (int(number) < int(rndm)):
        return f"<h1 style='color:red'>Too low, try again!</h1>" \
                "<img src='https://media.giphy.com/media/jD4DwBtqPXRXa/giphy.gif'>"
    else:
        return f"<h1 style='color:purple'>Too high, try again!</h1>" \
                "<img src='https://media.giphy.com/media/3o6ZtaO9BZHcOjmErm/giphy.gif'>"

if __name__ == "__main__":
    app.run(debug=True)
