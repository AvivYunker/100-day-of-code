from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
import time

driver = webdriver.Chrome()
actions = ActionChains(driver)

driver.get("https://instagram.com")
driver.maximize_window()
time.sleep(3)

email_field = driver.find_element(By.XPATH, '//input[@aria-label="Phone number, username, or email"]')
password_field = driver.find_element(By.XPATH, '//input[@aria-label="Password"]')
login_button = driver.find_element(By.XPATH, '//div[text()="Log in"]/..')
email_field.send_keys("johnmckay1223@gmail.com")
password_field.send_keys("zxcasdqwe123")
login_button.click()
time.sleep(5)


# First
driver.get("https://www.instagram.com/cookingforlevi/")
time.sleep(4)
followers_button = driver.find_element(By.XPATH, '//a[text()=" followers"]')
followers_button.click()
time.sleep(2)

follow_buttons = driver.find_elements(By.XPATH, '//div[text()="Follow"]')
for cnt in range(1, 5, 1):
    try:
        actions.move_to_element(follow_buttons[cnt]).perform()
        follow_buttons[cnt].click()
        time.sleep(0.75)
    except:
        pass
# Second
driver.get("https://www.instagram.com/cooking_tree/")
time.sleep(4)
followers_button = driver.find_element(By.XPATH, '//a[text()=" followers"]')
followers_button.click()
time.sleep(2)

follow_buttons = driver.find_elements(By.XPATH, '//div[text()="Follow"]')
for cnt in range(1, 5, 1):
    try:
        actions.move_to_element(follow_buttons[cnt]).perform()
        follow_buttons[cnt].click()
        time.sleep(0.75)
    except:
        pass


# Third
driver.get("https://www.instagram.com/thecookingfoodie/")
time.sleep(4)
followers_button = driver.find_element(By.XPATH, '//a[text()=" followers"]')
followers_button.click()
time.sleep(2)

follow_buttons = driver.find_elements(By.XPATH, '//div[text()="Follow"]')
for cnt in range(1, 5, 1):
    try:
        actions.move_to_element(follow_buttons[cnt]).perform()
        follow_buttons[cnt].click()
        time.sleep(0.75)
    except:
        pass

