import requests
from bs4 import BeautifulSoup

URL = "https://web.archive.org/web/20200518073855/https://www.empireonline.com/movies/features/best-movies-2/"

# Write your code below this line 👇


response = requests.get(URL, verify=False)
site = response.text
soup = BeautifulSoup(site, "html.parser")
#print(soup)

h3_tags = soup.find_all(name="h3")
print(h3_tags)


arr_best_movies = []
for h3 in h3_tags:
    arr_best_movies.append(h3.getText().encode('utf-8'))


arr_best_movies = arr_best_movies[::-1]


strr = ""
for movie in arr_best_movies:
    strr += str(movie) + "\n"

with open('movies.txt', 'a') as movies_file:
        movies_file.write(strr)
