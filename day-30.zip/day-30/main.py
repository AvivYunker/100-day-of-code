# from tkinter import *
import tkinter
from PIL import ImageTk, Image
from password import Password
from tkinter import messagebox as mb

ps1 = Password("","")

def generate_button_clicked():
    inserted_website = website_entry.get()
    inserted_email_username = email_username_entry.get()
    ps1.add_website(inserted_website)
    ps1.add_email_id(inserted_email_username)
    #print(f"The password from outside is: {ps1.password}")
    password_entry.delete(0, len(ps1.password))
    ps1.generate_password()
    password_entry.insert(0, ps1.password)
    window.clipboard_clear()
    window.clipboard_append(ps1.password)

def call():
    res = mb.askquestion('Warning', f'Email: {ps1.user_email_id}\nPassword: {ps1.password}\nIs this ok?')
    #print("res is: " + str(res))
    if res == 'yes':
        ps1.insert_into_txt("data.json")
    else:
        pass

def add_button_clicked():
    inserted_website = website_entry.get()
    inserted_email_username = email_username_entry.get()
    ps1.add_website(inserted_website)
    ps1.add_email_id(inserted_email_username)
    
    inserted_website = website_entry.get()
    inserted_email_username = email_username_entry.get()

    call()

def make_search():
    inserted_website = website_entry.get()
    email, password = ps1.search(inserted_website, "data.json")
    res = mb.showinfo(f"{inserted_website}", f"Email: {email}\nPassword: {password}")

    

window = tkinter.Tk()
window.title("Password Manager")
window.minsize(width=700, height=500)

# Red Lock Image "MyPass"
MyPassImg = ImageTk.PhotoImage(Image.open("logo.png"))
panel = tkinter.Label(window, image = MyPassImg)
panel.place(x=240, y=30)

# Label "Website:"
website_label = tkinter.Label(text="Website:", font=("Arial", 12))
website_label.place(x=100, y=250)

# Entry for website
website_entry = tkinter.Entry(width=40)
website_entry.place(x=200, y=250)
print(website_entry.get())

# Button for Search
generate_password_button = tkinter.Button(text="Search", font=("Arial", 12), width=16, command=make_search)
generate_password_button.place(x=470, y=245)

# Label "Email/Username:"
email_username_label = tkinter.Label(text="Email/Username:", font=("Arial", 12))
email_username_label.place(x=70, y=280)

# Entry for Email/Username
email_username_entry = tkinter.Entry(width=70)
email_username_entry.place(x=200, y=280)
print(email_username_entry.get())

# Label for "Password:"
password_label = tkinter.Label(text="Password:", font=("Arial", 12))
password_label.place(x=95, y=310)

# Entry for Password
password_entry = tkinter.Entry(width=40)
password_entry.place(x=200, y=310)
print(password_entry.get())

# Button for "Generate Password"
generate_password_button = tkinter.Button(text="Generate Password", font=("Arial", 12), command=generate_button_clicked)
generate_password_button.place(x=470, y=305)

# Button for "Add"
add_button = tkinter.Button(text="Add", font=("Arial", 12), width = 46, command=add_button_clicked)
add_button.place(x=200, y=340)

window.mainloop()

