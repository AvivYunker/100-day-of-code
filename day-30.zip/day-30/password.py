# RULES:
# must include at least one letter (uppercase or lowercase)
# must include at least one digit
# must include at lesat one special character from the following:
# # $ % ' ^ , ( ) * + . : | = ? @ / [ ] _ ` { } \ ! ; - ~
# must not match the user ID
# must not include more than 2 identical charcters (ex: 111 or aaa)
# must not include more than 2 consecutive characters (123 or abc)
# must not use the name of financial institutions (JPM, MORGAN, CHASE)
# must not be a commonly used password (ex: password1)
import random
import json

class Password():
    def __init__(self, website, user_email_id):
        self.password = ""
        self.website = website
        self.user_email_id = user_email_id
        self.letters = []
        self.commonly_used = ['123456','123456789','12345','qwerty','password','12345678','111111','123123','1234567890','1234567','qwerty123','000000','1q2w3e','aa12345678','abc123','password1','1234','qwertyuiop','123321','password123']
        self.financial_institutions = ['Transamerica Corporation','Ping An Insurance Group','ICBC','China Construction Bank','Agricultural Bank of China','China Life Insurance','Allianz','Bank of China','JP Morgan Chase','AXA''Fannie Mae','Generali Group','Bank of America','Citigroup','People’s Insurance Company','Crédit Agricole','BNP Paribas','HSBC','Wells Fargo','State Farm','Nippon Life Insurance','Munich Re','Dai-ichi Life Insurance','Banco Santander','MetLife','Bank of Communications','Freddie Mac','Legal & General Group','Brookfield Asset Management','Aviva','China Pacific Insurance','China Merchants Bank','Zurich Insurance Group','Manulife Financial','Aegon','Prudential Financial','Mitsubishi UFJ Financial Group','Prudential','StoneX Group Inc.','Goldman Sachs','Industrial Bank','Shanghai Pudong Development','Société Générale','Morgan Stanley','State Bank of India','Tokio Marine Holdings','AIA Group','China Minsheng Banking','Power Corporation of Canada']
        self.checked = False
        self.generate_password()
        self.check_password()

    def add_website(self, website):
        self.website = website

    def add_email_id(self, user_email_id):
        self.user_email_id = user_email_id

    def insert_into_txt(self, filename):
        # dict1 = {
        #     "website": self.website,
        #     "user_email_id": self.user_email_id,
        #     "password": self.password
        # }
        # with open (filename) as file:
        #     data = json.load(file)
        
        # data.update(dict1)

        # with open (filename, 'a') as file:
        #     json.dump(data, file)
        new_data = {
            self.website: {
                "email": self.user_email_id,
                "password": self.password
            }
        }
        with open("data.json", "r") as file:
            data = json.load(file)

        with open(filename, 'w') as file:
            json.dump(data, file, indent=4)



    def search(self, website, filename):
        with open (filename, 'r') as file:
            data = json.load(file)
            #print(data)
            for key in data:
                if (key == website):
                    return data[key]["email"], data[key]["password"]
        return "not found", "not found"





    def generate_password(self):
        self.password = ""
        for cnt in range(0, 12, 1):
            rndm_char_type = random.choice([0, 1, 2, 3]) # 0 = lower / 1 = upper / 2 = digit / 3 = special
            if (rndm_char_type == 0): # lowercase letter
                rndm_char = random.randint(97, 122)
                self.password += chr(rndm_char)
            elif (rndm_char_type == 1): # uppercase letter
                rndm_char = random.randint(65, 90)
                self.password += chr(rndm_char)
            elif (rndm_char_type == 2): # digit
                rndm_char = random.randint(48, 57)
                self.password += chr(rndm_char)
            elif (rndm_char_type == 3): # special
                self.password += random.choice(["#", "$", "%", "'", "^", ",", "(", ")", "*", "+", ".", ":", "|", "=", "?", "@", "/", "[", "]", "_", "`", "{", "}", "!", ";", "-", "~", "\\"])

    def check_password(self):
        temp = int(0)
        while (self.checked == False):
            if (temp == 0):
                for char in self.password: # must include at least one letter (uppercase or lowercase)
                    if (
                        (ord(char) >= 97 and ord(char) <= 122) or
                        (ord(char) >= 65 and ord(char) <= 90)
                    ):
                        temp = int(1)
                        break
            if (temp == 1): # must include at least one digit
                for char in self.password:
                    if (
                        (ord(char) >= 48 and ord(char) <= 57)
                    ):
                        temp = int(2)
                        break
            if (temp == 2): # must include at lesat one special character from the following:
                for char in self.password:
                    if (
                        char in ["#", "$", "%", "'", "^", ",", "(", ")", "*", "+", ".", ":", "|", "=", "?", "@", "/", "[", "]", "_", "`", "{", "}", "!", ";", "-", "~", "\\"]
                    ):
                        temp = int(3)
                        break
            if (temp == 3): # must not match the user ID
                if (self.password != self.user_email_id):
                    temp = int(4)
                    break
            if (temp == 4): # must not include more than 2 identical charcters (ex: 111 or aaa)
                for cnt in range(1, len(char), 1):
                    if (self.password[cnt] == self.password[cnt - 1]):
                        temp = int(-1)
                        break
                if (temp != int(-1)):
                    temp = int(5)
            if (temp == 5): # must not include more than 2 consecutive characters (123 or abc)
                for cnt in range(1, len(char), 1):
                    if (ord(self.password[cnt]) == ord(self.password[cnt - 1]) - 1):
                        temp = int(-1)
                        break
                if (temp != int(-1)):
                    temp = int(6)
            if (temp == 6): # must not use the name of financial institutions (JPM, MORGAN, CHASE)
                if (self.password not in self.financial_institutions):
                    temp = int(7)
            if (temp == 7): # must not be a commonly used password (ex: password1)
                if (self.password not in self.commonly_used):
                    temp = int(8)
            if (temp == 8):
                self.checked == True
            else:
                self.generate_password()
