question_data = [
{"text": "A slug's blood is green.", "answer": "True"},
{"text": "The loudest animal is the African Elephant.", "answer": "False"},
{"text": "Approximately one quarter of human bones are in the feet.", "answer": "True"},
{"text": "The total surface area of a human lungs is the size of a football pitch.", "answer": "True"},
{"text": "In West Virginia, USA, if you accidentally hit an animal with your car, you are free to take it home to eat.", "answer": "True"},
{"text": "In London, UK, if you happen to die in the House of Parliament, you are entitled to a state funeral.", "answer": "False"},
{"text": "It is illegal to pee in the Ocean in Portugal.", "answer": "True"},
{"text": "You can lead a cow down stairs but not up stairs.", "answer": "False"},
{"text": "Google was originally called 'Backrub'.", "answer": "True"},
{"text": "Buzz Aldrin's mother's maiden name was 'Moon'.", "answer": "True"},
{"text": "No piece of square dry paper can be folded in half more than 7 times.", "answer": "False"},
{"text": "A few ounces of chocolate can to kill a small dog.", "answer": "True"}
]

class Quiz():
    def __init__(self):
        self.score = int(0)
        self.asked_so_far = int(0)
        self.game_over = False
        self.ask_question()
    
    def ask_question(self):
        for cnt in range(0, len(question_data), 1):
            choice = input(f"Q{cnt+1}: {question_data[cnt]['text']} (True/False): ").title()
            while (choice != "True" and choice != "False"):
                print("Sorry. Your decision wasn't clear.")
                choice = input(f"Q{cnt+1}: {question_data[cnt]['text']} (True/False): ").title()
            correct = self.determine_answer(choice, cnt)
        self.ending_feedback(cnt)
            
            
    def determine_answer(self, choice, cnt):
        if (question_data[cnt]["answer"] == choice):
            self.score += 1
            self.current_feedback(True, cnt)
        else:
            self.score += 0
            self.current_feedback(False, cnt)
    
    def current_feedback(self, correct, cnt):
        if (correct == True):
            print(f"You got it right!\nThe correct answer was {question_data[cnt]['answer']}\nYour current score is: {self.score}/{cnt+1}")
        else:
            print(f"That's wrong.\nThe correct answer was {question_data[cnt]['answer']}\nYour current score is: {self.score}/{cnt+1}")

    def ending_feedback(self, cnt):
        print(f"You've completed the quiz\nYour final score was: {self.score}/{cnt+1}")

Q1 = Quiz()
