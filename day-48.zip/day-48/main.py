from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import random


driver = webdriver.Chrome()

driver.get("https://orteil.dashnet.org/experiments/cookie/")
time.sleep(5)

cookie = driver.find_element(By.XPATH, "//div[@id='cookie']")
money = driver.find_element(By.XPATH, "//div[@id='money']")

buy_cursor = driver.find_element(By.XPATH, "//div[@id='buyCursor']")
buy_cursor_requiments = driver.find_element(By.XPATH, "//div[@id='buyCursor']/b")

buy_grandma = driver.find_element(By.XPATH, "//div[@id='buyGrandma']")
buy_grandma_requiments = driver.find_element(By.XPATH, "//div[@id='buyGrandma']/b")

buy_factory = driver.find_element(By.XPATH, "//div[@id='buyFactory']")
buy_factory_requiments = driver.find_element(By.XPATH, "//div[@id='buyFactory']/b")

buy_mine = driver.find_element(By.XPATH, "//div[@id='buyMine']")
buy_mine_requiments = driver.find_element(By.XPATH, "//div[@id='buyMine']/b")

buy_shipment = driver.find_element(By.XPATH, "//div[@id='buyShipment']")
buy_shipment_requiments = driver.find_element(By.XPATH, "//div[@id='buyShipment']/b")

buy_alchemy_lab = driver.find_element(By.XPATH, "//div[@id='buyAlchemy lab']")
buy_alchemy_lab_requiments = driver.find_element(By.XPATH, "//div[@id='buyAlchemy lab']/b")

buy_portal = driver.find_element(By.XPATH, "//div[@id='buyPortal']")
buy_portal_requiments = driver.find_element(By.XPATH, "//div[@id='buyPortal']/b")

buy_time_machine = driver.find_element(By.XPATH, "//div[@id='buyTime machine']")
buy_time_machine_requiments = driver.find_element(By.XPATH, "//div[@id='buyTime machine']/b")

buy_elder_pledge = driver.find_element(By.XPATH, "//div[@id='buyElder Pledge']")
buy_elder_pledge_requiments = driver.find_element(By.XPATH, "//div[@id='buyElder Pledge']/b")



seconds_remaining = 5
start = time.time()
while (True):    
    cookie.click()
    if time.time() - seconds_remaining > start:
        start = time.time()
