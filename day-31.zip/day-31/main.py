import tkinter
from PIL import ImageTk, Image, ImageDraw, ImageFont
import pandas
import json
import time

BACKGROUND_COLOR = "#B1DDC6"
DARKER_BACKGROUND_COLOR = "#91C2AF"
BLACK = "#000000"
WHITE = "#ffffff"

file = pandas.read_csv("data/french_words.csv")

french_words = file['French'].tolist()
english_words = file['English'].tolist()

dict_words = {}

for count in range(0, len(french_words), 1):
    dict_words[french_words[count]] = [english_words[count], 0]

#print(dict_words)

def save_to_json(filename, dict_words):
    with open(filename, 'w') as file:
        json.dump(dict_words, file, indent=2)

def load_json(filename):
    with open (filename, 'r') as file:
        data = json.load(file)
    return data

def check_finished(all_words):
    for key in all_words:
        if (all_words[key][1] < 3):
            return False
    return True

def x_button_clicked():
    print("NO")
    window.after(3000, show_french)

def y_button_clicked():
    print("YES")
    show_english()
    all_words[keys_list[cnt.get()]][1] += 1
    save_to_json("data.json", all_words)
    window.after(3000, show_french)

def get_to_not_three():
    try:
        while (all_words[keys_list[cnt.get()]][1] == 3):
            cnt.set(cnt.get() + 1)
    except:
        print("Went overboard...")

def show_french():
    cnt.set(cnt.get() + 1)
    get_to_not_three()
    hide_language()
    FrontCardPanel.place(x=50, y=50)
    word_label.configure(fg=BLACK, bg=WHITE, text="French")
    actual_word.configure(fg=BLACK, bg=WHITE, text=keys_list[cnt.get()])
    word_label.place(x=340, y=170)
    actual_word.place(x=330, y=280)
    window.after(3000, show_english)


def show_english():
    hide_language()
    BackCardPanel.place(x=50, y=50)
    word_label.configure(fg=WHITE, bg=DARKER_BACKGROUND_COLOR, text="English")
    actual_word.configure(fg=WHITE, bg=DARKER_BACKGROUND_COLOR, text=all_words[keys_list[cnt.get()]][0])
    word_label.place(x=340, y=170)
    actual_word.place(x=330, y=280)


def hide_language():
    FrontCardPanel.place_forget()
    BackCardPanel.place_forget()
    word_label.place_forget()
    actual_word.place_forget()




# Window setup
window = tkinter.Tk()
window.title("Flashy")
window.minsize(width=900, height=725)
window.configure(bg=BACKGROUND_COLOR)

# Front-card Image
FrontCardImage = ImageTk.PhotoImage(Image.open("images/card_front.png"))
FrontCardPanel = tkinter.Label(window, image = FrontCardImage, bg=BACKGROUND_COLOR)
#FrontCardPanel.place(x=50, y=50)

# Back-card Image
BackCardImage = ImageTk.PhotoImage(Image.open("images/card_back.png"))
BackCardPanel = tkinter.Label(window, image = BackCardImage, bg=BACKGROUND_COLOR)
#BackCardPanel.place(x=210, y=190)

# "French" / "English" label
word_label = tkinter.Label(text="French", font=("Arial", 45, "italic"), fg=BLACK, bg=WHITE)
#word_label.place(x=340, y=170)

# French / English Word
actual_word = tkinter.Label(text="", font=("Arial", 60), fg=BLACK, bg=WHITE)
#actual_word.place(x=330, y=280)

cnt = tkinter.IntVar()

# X_button
WrongImage = ImageTk.PhotoImage(Image.open("images/wrong.png"))
x_button = tkinter.Button(window, image = WrongImage, bg=BACKGROUND_COLOR, command=x_button_clicked)
x_button.place(x=200, y=580)

# V_button
RightImage = ImageTk.PhotoImage(Image.open("images/right.png"))
v_button = tkinter.Button(window, image = RightImage, bg=BACKGROUND_COLOR, command=y_button_clicked)
v_button.place(x=600, y=580)

#save_to_json("data.json", dict_words)
all_words = load_json("data.json")
keys_list = list(all_words.keys())
cnt = tkinter.IntVar()
cnt.set(-1)
get_to_not_three()
#print(all_words[keys_list[cnt.get()]][0])

show_french()

window.mainloop()
