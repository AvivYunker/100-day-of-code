##################### Extra Hard Starting Project ######################

# 1. Update the birthdays.csv

# 2. Check if today matches a birthday in the birthdays.csv

# 3. If step 2 is true, pick a random letter from letter templates and replace the [NAME] with the person's actual name from birthdays.csv

# 4. Send the letter generated in step 3 to that person's email address.

import pandas
import random
import datetime
import smtplib


my_email = "testing99128923@gmail.com"
my_password = "bltocpffxrraoaad"

dates = []

birthdays = pandas.read_csv('birthdays.csv')
birthdays_dict = birthdays.to_dict()
for _ in range(len(birthdays_dict['name'])):
    dates.append([])

#print(dates)



for cnt in birthdays_dict["day"]:
    #print(birthdays_dict["day"][cnt])
    dates[cnt].append(birthdays_dict["day"][cnt])

for cnt in birthdays_dict["month"]:
    dates[cnt].append(birthdays_dict["month"][cnt])

for cnt in birthdays_dict["year"]:
    dates[cnt].append(birthdays_dict["year"][cnt])

for cnt in range(0, len(dates), 1):
    dates[cnt].append(birthdays_dict["name"][cnt])

#print(dates)
now = datetime.datetime.now()
#print(now.year)
#print(now.month)
#print(now.day)
for individual in dates:
    if (
        (now.day == individual[0]) and
        (now.month == individual[1])
    ):
        random_template = random.choice(["letter_1.txt", "letter_2.txt", "letter_3.txt",])
        birthday_card = open(f"letter_templates/{random_template}")
        rows = birthday_card.readlines()
        if (random_template == "letter_1.txt" or random_template == "letter_3.txt"):
            rows[0] = f"Dear {individual[3]},\n"
        else:
            rows[0] = f"Hey {individual[3]},\n"
        birthday_wish = ""
        for row in rows:
            birthday_wish += row
        connection = smtplib.SMTP("smtp.gmail.com")
        connection.starttls()
        connection.login(user=my_email, password=my_password)
        connection.sendmail(
            from_addr=my_email,
            to_addrs="avivyunker@gmail.com",
            msg=f"Subject:Birthday Letter\n\n{birthday_wish}"
        )
        connection.close()
