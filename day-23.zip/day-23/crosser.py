from turtle import Turtle, Screen


# Define the window
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("white")
screen.title("Turtle Crossing")

class Crosser():
    def __init__(self):
        screen.tracer(0)
        self.crosser = Turtle()
        self.crosser.color("black")
        self.crosser.shape("turtle")
        self.crosser.penup()
        self.crosser.left(90)
        self.crosser.turtlesize(1.5)
        self.crosser.setpos(0, -380) # ORIGINAL
        screen.tracer(1)

    def forward(self):
        screen.tracer(0)
        self.crosser.forward(20)
        self.check_reached_end()
        screen.tracer(1)

    def check_reached_end(self):
        if (self.crosser.pos()[1] > 300):
            return True
    
    def back_to_start(self):
        screen.tracer(0)
        self.crosser.setpos(0, -380)
        screen.tracer(1)

# TRYOUT:

#crosser1 = Crosser()

#screen.listen()
#screen.onkey(key="w", fun=crosser1.forward)
#screen.onkey(key="s", fun=crosser1.backwards)
#screen.onkey(key="a", fun=crosser1.left)
#screen.onkey(key="d", fun=crosser1.right)

#screen.onkey(key="Up", fun=crosser1.forward)
#screen.onkey(key="Down", fun=crosser1.backwards)
#screen.onkey(key="Left", fun=crosser1.left)
#screen.onkey(key="Right", fun=crosser1.right)
