from turtle import Turtle, Screen
import random
import time


# Define the window
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("white")
screen.title("Turtle Crossing")

class CarManager():
    def __init__(self):
        self.all_cars = []

    def generate_car(self):
        screen.tracer(0)
        new_car = Turtle("square")
        new_car.shapesize(stretch_wid=1, stretch_len=2)
        new_car.penup()
        new_car.color(random.choice(["green", "blue", "yellow", "red", "orange", "purple"]))
        random_y = random.randint(-250, 250)
        new_car.goto(300, random_y)
        self.all_cars.append(new_car)
        screen.tracer(1)

    def move_cars(self):
        for car in self.all_cars:
            car.backward(5)
    
    def check_collision(self, turtle_pos_x, turtle_pos_y):
        for car in self.all_cars:
            if (abs(car.pos()[0] - turtle_pos_x) < 30) and (abs(car.pos()[1] - turtle_pos_y) < 30):
                #print("1")
                return True
        #print("0")
        return False

# TRYOUT:
#cars = []
#for cnt in range(0, 20, 1):
#    cars.append(Car(5))

#while (True):
#    screen.tracer(0)
#    for cnt in range(0, len(cars), 1):
#        cars[cnt].move()
#    screen.tracer(1)

#c1 = Car(5)
#c2 = Car(5)
#c3 = Car(5)
#c4 = Car(5)
#c5 = Car(5)
