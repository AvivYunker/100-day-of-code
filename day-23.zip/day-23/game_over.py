from turtle import Turtle, Screen

# Define the window
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("white")
screen.title("Turtle Crossing")

class GameOver():
    def __init__(self):
        self.turtle = Turtle()
        self.turtle.color("black")
        self.turtle.penup()
        self.turtle.hideturtle()

    def render_game_over(self):
        screen.tracer(0)
        self.turtle.clear()
        self.text = "Game Over"
        self.turtle.goto(-70, 0)
        self.turtle.write(self.text, (60,50), font=("Courier", 30, "bold"))
        screen.tracer(1)

# TRYOUT:
#sc1 = Score()
