from turtle import Turtle, Screen


# Define the window
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("white")
screen.title("Turtle Crossing")

class Score():
    def __init__(self):
        self.turtle = Turtle()
        self.turtle.color("black")
        self.turtle.penup()
        self.turtle.hideturtle()
        self.score = int(0)
        self.text = "0"
        self.render_score()

    def render_score(self):
        screen.tracer(0)
        self.turtle.clear()
        self.text = f"Level: {self.score}"
        self.turtle.goto(-450, 330)
        self.turtle.write(self.text, (60,50), font=("Courier", 30, "bold"))
        #self.turtle.write("SAMPLE-TEXT", align="left", move=True)
        screen.tracer(1)

    def increase_score(self):
        self.score += 1
        self.render_score()


# TRYOUT:
#sc1 = Score()
