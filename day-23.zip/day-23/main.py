from turtle import Turtle, Screen
import time

from crosser import Crosser
from score import Score
from car_manager import CarManager
from game_over import GameOver


# Define the window
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("white")
screen.title("Turtle Crossing")

times = [0.001, 0.0001, 0.00001, 0.000001, 0.0000001, 0.00000001, 0.000000001]

crosser1 = Crosser()
sc1 = Score()
go1 = GameOver()
car_manager = CarManager()

screen.listen()
screen.onkey(key="w", fun=crosser1.forward)
screen.onkey(key="Up", fun=crosser1.forward)

game_over = False
while (game_over == False):
    time.sleep(times[sc1.score])
    screen.update()
    car_manager.generate_car()
    car_manager.move_cars()
    game_over = car_manager.check_collision(crosser1.crosser.pos()[0], crosser1.crosser.pos()[1])
    if (game_over == True):
        break
    if (crosser1.check_reached_end() == True):
        sc1.increase_score()
        crosser1.back_to_start()

if (game_over == True):
    go1.render_game_over()
