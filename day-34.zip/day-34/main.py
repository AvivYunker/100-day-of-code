import requests
import tkinter
from PIL import ImageTk, Image
import html

THEME_COLOR = "#375362"
WHITE = "#FFFFFF"
BLACK = "#000000"
GREEN = "#088f01"
RED = "#bf0000"

def check_answer(bool):
    if (str(bool) == data[cnt.get()]['correct_answer']):
        #canvas.itemconfigure(question_text, text=data[cnt.get()]["question"])
        canvas.configure(bg=GREEN)
        score.set(score.get() + 1)
    else:
        #canvas.itemconfigure(question_text, text=data[cnt.get()]["question"])
        canvas.configure(bg=RED)
        score.set(score.get() + 0)
    score_label.configure(fg=WHITE, bg=THEME_COLOR, text=f"Score: {score.get()}")
    window.update()
    return score.get()

def v_button_press():
    score.set(check_answer(True))
    cnt.set(cnt.get() + 1)
    try:
        canvas.itemconfigure(question_text, text=html.unescape(data[cnt.get()]["question"]))
        window.after(1000, canvas.configure(bg=WHITE))
    except:
        canvas.configure(bg=WHITE)
        canvas.itemconfigure(question_text, text="GAME OVER")

def x_button_press():
    score.set(check_answer(False))
    cnt.set(cnt.get() + 1)
    try:
        canvas.itemconfigure(question_text, text=html.unescape(data[cnt.get()]["question"]))
        window.after(1000, canvas.configure(bg=WHITE))

    except:
        canvas.configure(bg=WHITE)
        canvas.itemconfigure(question_text, text="GAME OVER")
    #print("X")

response = requests.get(url="https://opentdb.com/api.php?amount=30&type=boolean", verify=False)
response.raise_for_status()
data = response.json()
data = list(data["results"])

# Window setup
window = tkinter.Tk()
window.title("Flashy")
window.minsize(width=400, height=500)
window.configure(bg=THEME_COLOR)

cnt = tkinter.IntVar()
score = tkinter.IntVar()
score.set(int(0))

# Score
score_label = tkinter.Label(window, text=f"Score: {score.get()}", font=("Arial", 20), bg=THEME_COLOR, fg=WHITE)
score_label.place(x=200, y=20)


# Question Window
canvas = tkinter.Canvas(width=300, height=230)
question_text = canvas.create_text(130, 80, text="AAA", width=250, font=("Arial", 15), fill=BLACK)
canvas.place(x=50, y=100)

# V button
v_image = ImageTk.PhotoImage(Image.open("images/true.png"))
v_button = tkinter.Button(window, image = v_image, bg=THEME_COLOR, command=v_button_press)
v_button.place(x=70, y=370)


# X button
x_image = ImageTk.PhotoImage(Image.open("images/false.png"))
x_button = tkinter.Button(window, image = x_image, bg=THEME_COLOR, command=x_button_press)
x_button.place(x=230, y=370)



canvas.itemconfigure(question_text, text=html.unescape(data[cnt.get()]["question"]))


window.mainloop()
