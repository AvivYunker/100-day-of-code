from turtle import Turtle, Screen
import random

t1 = Turtle() # Purple
t2 = Turtle() # Blue
t3 = Turtle() # Green
t4 = Turtle() # Yellow
t5 = Turtle() # Orange
t6 = Turtle() # Red

t1.penup()
t2.penup()
t3.penup()
t4.penup()
t5.penup()
t6.penup()

t1.shape("turtle")
t2.shape("turtle")
t3.shape("turtle")
t4.shape("turtle")
t5.shape("turtle")
t6.shape("turtle")

t1.color("purple")
t2.color("blue")
t3.color("green")
t4.color("yellow")
t5.color("orange")
t6.color("red")


t1.setpos(-450, 120)
t2.setpos(-450, 70)
t3.setpos(-450, 20)
t4.setpos(-450, -30)
t5.setpos(-450, -80)
t6.setpos(-450, -130)

arr_players = [1,2,3,4,5,6]

while (
    t1.pos()[0] < 430 and
    t2.pos()[0] < 430 and
    t3.pos()[0] < 430 and
    t4.pos()[0] < 430 and
    t5.pos()[0] < 430 and
    t6.pos()[0] < 430
):
    random.shuffle(arr_players)
    for cnt in range(0, len(arr_players), 1):
        if (arr_players[cnt] == 1):
            t1.forward(random.randrange(0, 100))
        elif (arr_players[cnt] == 2):
            t2.forward(random.randrange(0, 100))
        elif (arr_players[cnt] == 3):
            t3.forward(random.randrange(0, 100))
        elif (arr_players[cnt] == 4):
            t4.forward(random.randrange(0, 100))
        elif (arr_players[cnt] == 5):
            t5.forward(random.randrange(0, 100))
        elif (arr_players[cnt] == 6):
            t6.forward(random.randrange(0, 100))


if (t1.pos()[0] >= 430):
    print("Purple turtle won!")
elif (t2.pos()[0] >= 430):
    print("Blue turtle won!")
elif (t3.pos()[0] >= 430):
    print("Green turtle won!")
elif (t4.pos()[0] >= 430):
    print("Yellow turtle won!")
elif (t5.pos()[0] >= 430):
    print("Orange turtle won!")
elif (t6.pos()[0] >= 430):
    print("Red turtle won!")

screen = Screen()
screen.exitonclick()
