from turtle import Turtle, Screen
from wall import Wall
import time
HEIGHT = 300
WIDTH = 300
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

class Snake():
    def __init__(self):
        self.body = []
        self.score = int(0)
        self.create_body()

    def create_body(self):
        screen.tracer(0)
        x_temp = int(0)
        for _ in range(3):
            self.body.append(self.new_square(x_temp,0))
            x_temp -= 20
        #print("self.body[0].heading(): " + str(self.body[0].heading()))
        #print("type(self.body[0].heading()): " + str(type(self.body[0].heading())))
        screen.tracer(1)

    def grow_by_one(self):
        screen.tracer(0)
        if (self.body[0].heading() == 0.0):
            self.body.append(self.new_square(self.body[len(self.body)-1].pos()[0] - 20, self.body[len(self.body)-1].pos()[1]))
        elif (self.body[0].heading() == 90.0):
            self.body.append(self.new_square(self.body[len(self.body)-1].pos()[0], self.body[len(self.body)-1].pos()[1] - 20))
        elif (self.body[0].heading() == 180.0):
            self.body.append(self.new_square(self.body[len(self.body)-1].pos()[0] + 20, self.body[len(self.body)-1].pos()[1]))
        elif (self.body[0].heading() == 270.0):
            self.body.append(self.new_square(self.body[len(self.body)-1].pos()[0], self.body[len(self.body)-1].pos()[1] + 20))
        screen.tracer(1)

    def new_square(self, x, y):
        square = Turtle()
        square.color("white")
        square.shape("square")
        square.pensize(20)
        square.penup()
        #square.hideturtle()
        square.setpos(x, y)
        return square

    def move(self): # 0 / 90 / 180 / 270
        time.sleep(0.1)
        screen.tracer(0)
        for part in range(len(self.body)-1, 0, -1):
            self.body[part].setpos(self.body[part - 1].pos()[0], self.body[part - 1].pos()[1])
        if (self.body[0].heading() == 0.0): # going right
            self.body[0].setpos(self.body[0].pos()[0] + 20, self.body[0].pos()[1])
        elif (self.body[0].heading() == 90.0): # going up
            self.body[0].setpos(self.body[0].pos()[0], self.body[0].pos()[1] + 20)
        elif (self.body[0].heading() == 180.0): # going left
            self.body[0].setpos(self.body[0].pos()[0] - 20, self.body[0].pos()[1])
        elif (self.body[0].heading() == 270.0): # going down
            self.body[0].setpos(self.body[0].pos()[0], self.body[0].pos()[1] - 20)
        screen.tracer(1)
        time.sleep(0.1)

# 0.0 = right
# 90.0 = up
# 180.0 = left
# 270.0 = down

    def turn_east(self):
        if ((self.body[0].heading() != 0.0) and (self.body[0].heading() != 180.0)):
            screen.tracer(0)
            self.body[0].setheading(0.0)
            screen.tracer(1)
            #print("current heading: " + str(self.body[0].heading()))
    def turn_north(self):
        if ((self.body[0].heading() != 90.0) and (self.body[0].heading() != 270.0)):
            screen.tracer(0)
            self.body[0].setheading(90.0)
            screen.tracer(1)
            #print("current heading: " + str(self.body[0].heading()))
    def turn_west(self):
        if ((self.body[0].heading() != 180.0) and (self.body[0].heading() != 0.0)):
            screen.tracer(0)
            self.body[0].setheading(180.0)
            screen.tracer(1)
            #print("current heading: " + str(self.body[0].heading()))
    def turn_south(self):
        if ((self.body[0].heading() != 270.0) and (self.body[0].heading() != 90.0)):
            screen.tracer(0)
            self.body[0].setheading(270.0)
            screen.tracer(1)
            #print("current heading: " + str(self.body[0].heading()))

    def check_body_crash(self):
        for part in range(2, len(self.body), 1):
            #print("self.body[0].pos()[0]: " + str(self.body[0].pos()[0]))
            #print("self.body[part].pos()[0]: " + str(self.body[part].pos()[0]))
            #print("self.body[0].pos()[1]: " + str(self.body[0].pos()[1]))
            #print("self.body[part].pos()[1]: " + str(self.body[part].pos()[1]))
            if (
                (abs(self.body[0].pos()[0] - self.body[part].pos()[0]) < 5) and
                (abs(self.body[0].pos()[1] - self.body[part].pos()[1]) < 5)
            ):
                return True
            else:
                pass
                #print("X:" + str(self.body[0].pos()[0] == self.body[part].pos()[0]))
                #print("Y:" + str(self.body[0].pos()[1] == self.body[part].pos()[1]))


# TRYOUTS:
#s1 = Snake()
#s1.move()
