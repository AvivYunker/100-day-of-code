from turtle import Turtle, Screen
from snake import Snake
from food import Food
from wall import Wall
from score import Score

# Define the window
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

s1 = Snake()
f1 = Food()
w1 = Wall()
sc1 = Score()

screen.listen()
screen.onkey(key="d", fun=s1.turn_east)
screen.onkey(key="w", fun=s1.turn_north)
screen.onkey(key="a", fun=s1.turn_west)
screen.onkey(key="s", fun=s1.turn_south)
screen.onkey(key="Right", fun=s1.turn_east)
screen.onkey(key="Up", fun=s1.turn_north)
screen.onkey(key="Left", fun=s1.turn_west)
screen.onkey(key="Down", fun=s1.turn_south)


game_over = False
while (game_over == False):
    s1.move()
    game_over = s1.check_body_crash()
    if (game_over == True):
        break
    eaten = f1.check_food_eaten(s1.body[0].pos()[0], s1.body[0].pos()[1])
    if (eaten == True):
        sc1.increase_current_score()
        sc1.update_high_score()
        sc1.render_text()
        s1.grow_by_one()
    game_over = w1.check_crash_wall(s1.body[0].pos()[0], s1.body[0].pos()[1])
    if (game_over == True):
        break

sc1.update_high_score()
sc1.update_high_score_file("highscore")
sc1.render_game_over()
#print("GAME OVER")
