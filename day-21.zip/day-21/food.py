from turtle import Turtle, Screen
import time
import random
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

class Food():
    def __init__(self):
        self.food = Turtle()
        self.food.hideturtle()
        #self.food.shape("circle")
        self.food.shape("square")
        self.food.color("Blue")
        self.food.penup()
        self.food.turtlesize(1)
        self.set_food()


    def set_food(self):
        rand_x = random.randint(-350,340)
        rand_y = random.randint(-280,290)
        self.food.setpos(rand_x, rand_y)
        self.food.showturtle()

    def check_food_eaten(self, head_pos_x, head_pos_y):
        if (
            (abs(head_pos_x - self.food.pos()[0]) < 15) and
            (abs(head_pos_y - self.food.pos()[1]) < 15)
        ):
            #print("Nom-Nom-Nom")
            screen.tracer(0)
            self.remove_food()
            self.set_food()
            screen.tracer(1)
            return True
        else:
            return False

    def remove_food(self):
        self.food.hideturtle()


# TRYOUTS:
#f1 = Food()
