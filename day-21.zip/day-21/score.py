from turtle import Turtle, Screen
HEIGHT = 600
WIDTH = 600
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

class Score():
    def __init__(self):
        self.current_score = int(0)
        self.get_high_score("highscore")
        self.text = f"Current Score: {self.current_score} / High-Score: {self.high_score}"
        self.turtle = Turtle()
        self.turtle.penup()
        self.turtle.pencolor("white")
        self.turtle.hideturtle()
        self.render_text()

    def get_high_score(self, filename):
        with open(f"{filename}.txt") as file:
            contents = file.read()
            if (len(contents) == 0):
                contents = 0
            self.high_score = contents
            file.close()

    def write_high_score(self, filename):
        with open(f"{filename}.txt", 'w') as file:
            #print("ONE")
            file.write(str(self.high_score))
            #print("TWO")
            file.close()
            #print("THREE")

    def update_high_score(self):
        if (self.current_score >= int(self.high_score)):
            self.high_score = int(self.current_score)

    def increase_current_score(self):
        self.current_score += 1

    def update_high_score_file(self, filename):
        #print("/////////////////////")
        #print("self.current_score: " + str(self.current_score))
        #print("type(self.current_score): " + str(type(self.current_score)))
        #print("self.get_high_score(filename): " + str(self.get_high_score(filename)))
        #print("type(self.get_high_score(filename)): " + str(type(self.get_high_score(filename))))
        #print("/////////////////////")
        #self.get_high_score(filename)
        if (int(self.current_score) >= int(self.high_score)):
            self.update_high_score()
            self.write_high_score(filename)

    def render_text(self):
        screen.tracer(0)
        self.turtle.clear()
        self.text = f"Current Score: {self.current_score} / High-Score: {self.high_score}"
        self.turtle.goto(-250, 260)
        self.turtle.write(self.text, (60,50), font=("Courier", 20, "bold"))
        #self.turtle.write("SAMPLE-TEXT", align="left", move=True)
        screen.tracer(1)

    def render_game_over(self):
        screen.tracer(0)
        self.turtle.goto(-100, 0)
        self.turtle.write("GAME OVER", (50,50), font=("Courier", 20, "bold"))
        screen.tracer(1)

# TRYOUTS:
#sc1 = Score()
#sc1.render_text(5)
