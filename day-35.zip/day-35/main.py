import requests
from twilio.rest import Client

OWM_Endpoint = "https://api.openweathermap.org/data/2.8/onecall"
api_key = "30a3836d40a27d400d4e8218229d173e"
account_sid = "AC14a57c595093ed1dcd4e5cda5ba13c2b"
auth_token = "d398cc2bbd129594de6e62812355a862"

weather_params = {
    "lat": 31.262361,
    "lon": 34.795922,
    "appid": api_key,
    "exclude": "current,minutely,daily"
}

response = requests.get(OWM_Endpoint, params=weather_params, verify=False)
data = response.json()

def check_raining():
    for cnt in range(0, 12, 1):
        if (data['hourly'][cnt]['weather'][0]['id'] <= 700):
            return True
    return False

going_to_rain = check_raining()
if (going_to_rain):
    client = Client(account_sid, auth_token)
    message = client.messages.create(
        body="It's going to rain today. Remember to bring an ☂️",
        from_="+12059316862",
        to="+972535284358"
    )
