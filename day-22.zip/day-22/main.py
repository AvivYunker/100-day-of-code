from turtle import Turtle, Screen
from paddle import Paddle
from dashed_line import DashedLine
from score import Score
from borders import Border
from ball import Ball
from dashed_line import DashedLine

# Define the window
HEIGHT = 600
WIDTH = 800
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Pong Game")

dl = DashedLine()

s1 = Score(-140, 250)
s2 = Score(60, 250)

p1 = Paddle(-440, 100)
p2 = Paddle(430, 100)

top = Border(-470, 392, 930, False)
right = Border(460, 392, 775, True)
left = Border(-470, 392, 775, True)
bottom = Border(-470, -385, 930, False)

screen.listen()
screen.onkey(key="q", fun=p1.go_up)
screen.onkey(key="a", fun=p1.go_down)
screen.onkey(key="w", fun=p1.go_up)
screen.onkey(key="s", fun=p1.go_down)
screen.onkey(key="Up", fun=p2.go_up)
screen.onkey(key="Down", fun=p2.go_down)

b1 = Ball()
while (True):
    b1.move( p1, p2, top, right, left, bottom, s1, s2)
