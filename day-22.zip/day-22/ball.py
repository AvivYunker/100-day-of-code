from turtle import Turtle, Screen
from borders import Border
from score import Score
from paddle import Paddle
import time
import random
HEIGHT = 300
WIDTH = 300
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

class Ball():
    def __init__(self):
        self.ball = Turtle()
        self.ball.pensize(3)
        self.ball.penup()
        self.ball.shape("circle")
        self.ball.color("white")
        #self.ball.angle = 45
        self.regenerate_ball()

    def move(self, p1, p2, top, right, left, bottom, s1, s2):
        screen.tracer(0)
        self.ball.forward(5)
        
        # Collision with borders
        if (top.check_collision(self.ball.pos()[0], self.ball.pos()[1]) == True):
            self.ball.setheading(self.ball.heading() * -1)
        elif (right.check_collision(self.ball.pos()[0], self.ball.pos()[1]) == True):
            #self.ball.setheading(self.ball.heading() * 3)
            s1.increase_score()
            self.regenerate_ball()
        elif (left.check_collision(self.ball.pos()[0], self.ball.pos()[1]) == True):
            #self.ball.setheading(self.ball.heading() * 3)
            s2.increase_score()
            self.regenerate_ball()
        elif (bottom.check_collision(self.ball.pos()[0], self.ball.pos()[1]) == True):
            self.ball.setheading(self.ball.heading() * -1)
        
        # Collision with Paddles
        if (p1.check_collision(self.ball.pos()[0], self.ball.pos()[1]) == True):
            self.ball.setheading(self.ball.heading() * 3)
            self.ball.speed(self.ball.speed() + 1)
        elif (p2.check_collision(self.ball.pos()[0], self.ball.pos()[1]) == True):
            self.ball.setheading(self.ball.heading() * 3)
            self.ball.speed(self.ball.speed() + 1)
        screen.tracer(1)
        time.sleep(0.01)
    
    def regenerate_ball(self):
        self.ball.speed(1)
        screen.tracer(0)
        self.ball.setpos(0,0)
        self.ball.setheading(random.choice([45, 135, 225, 315]))
        screen.tracer(1)


# TRYOUT:
#b1 = Ball()
#while (True):
#    b1.move()
