from turtle import Turtle, Screen
HEIGHT = 300
WIDTH = 300
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

class Score():
    def __init__(self, x_pos, y_pos):
        self.turtle = Turtle()
        self.turtle.color("white")
        self.turtle.penup()
        self.turtle.hideturtle()
        self.score = int(0)
        self.text = "0"
        self.x_position = x_pos
        self.y_position = y_pos
        self.render_score()

    def render_score(self):
        screen.tracer(0)
        self.turtle.clear()
        self.text = f"{self.score}"
        self.turtle.goto(self.x_position, self.y_position)
        self.turtle.write(self.text, (60,50), font=("Courier", 100, "bold"))
        #self.turtle.write("SAMPLE-TEXT", align="left", move=True)
        screen.tracer(1)
    
    def increase_score(self):
        self.score += 1
        self.render_score()

# TRYOUT:
#s1 = Score(-130, 250)
#s2 = Score(50, 250)
