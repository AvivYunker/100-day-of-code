from turtle import Turtle, Screen
HEIGHT = 300
WIDTH = 300
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

class Paddle():
    def __init__(self, x_pos, y_pos):
        self.x_position = x_pos
        self.y_position = y_pos
        self.paddle = []
        self.create_paddle()
    
    def create_paddle(self):
        screen.tracer(0)
        for cnt in range(0, 6, 1):
            self.paddle.append(Turtle())
            self.paddle[cnt].shape("square")
            self.paddle[cnt].color("white")
            self.paddle[cnt].penup()
            self.paddle[cnt].turtlesize(1.2)
            self.paddle[cnt].setpos(self.x_position, self.y_position - 20 * cnt)
        screen.tracer(1)
    
    def go_up(self):
        screen.tracer(0)
        for part in range(0, len(self.paddle), 1):
            self.paddle[part].setpos(self.paddle[part].pos()[0], self.paddle[part].pos()[1] + 40)
        screen.tracer(1)
    
    def go_down(self):
        screen.tracer(0)
        for part in range(0, len(self.paddle), 1):
            self.paddle[part].setpos(self.paddle[part].pos()[0], self.paddle[part].pos()[1] - 40)
        screen.tracer(1)
    
    def check_collision(self, ball_x_pos, ball_y_pos):
        for part in self.paddle:
            if (
                (abs(part.pos()[0] - ball_x_pos) < 15) and
                (abs(part.pos()[1] - ball_y_pos) < 15)
            ):
                return True
        return False



# TRYOUT:
#p1 = Paddle(450, 100)
#p2 = Paddle(-450, 100)

#screen.listen()
#screen.onkey(key="q", fun=p1.go_up)
#screen.onkey(key="a", fun=p1.go_down)
#screen.onkey(key="w", fun=p1.go_up)
#screen.onkey(key="s", fun=p1.go_down)
#screen.onkey(key="Up", fun=p2.go_up)
#sscreen.onkey(key="Down", fun=p2.go_down)
