from turtle import Turtle, Screen
HEIGHT = 300
WIDTH = 300
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

class DashedLine():
    def __init__(self):
        self = Turtle()
        self.setpos(0, 390)
        self.color("white")
        self.shape("square")
        self.pensize(10)
        screen.tracer(0)
        self.right(90)
        for cnt in range(0, 30, 1):
            self.penup()
            self.forward(20)
            self.pendown()
            self.forward(5)
        self.hideturtle()
        screen.tracer(1)

# TRYOUT:
#d1 = DashedLine()
