from turtle import Turtle, Screen
HEIGHT = 300
WIDTH = 300
screen = Screen()
screen.screensize(WIDTH, HEIGHT)
screen.bgcolor("black")
screen.title("Snake Game")

class Border():
    def __init__(self, x_pos, y_pos, stretch, functional):
        # "functional" means that if the ball hits it, it will score a point for the rival
        self.border = Turtle()
        self.border.shape("square")
        self.border.penup()
        self.border.pensize(20)
        self.border.color("black")
        self.border_type = functional
        self.stretch = stretch
        self.x_position = x_pos
        self.y_position = y_pos
        self.draw_border()
    
    def draw_border(self):
        screen.tracer(0)
        self.border.setpos(self.x_position, self.y_position)
        self.border.pendown()
        if (self.border_type == True):
            self.border.right(90)
        self.border.forward(self.stretch)    
        screen.tracer(1)
    
    def check_collision(self, ball_x_pos, ball_y_pos):
        if (
            (self.border_type == True) and # left / right borders
            (abs(ball_x_pos - self.x_position) < 2)
        ):
            print("GOAL!")
            return True
        elif (
            (self.border_type == False) and # top / bottom borders
            (abs(ball_y_pos - self.y_position) < 5)
        ):
            print("COLLISION!")
            return True
        else:
            return False

# Functional "True" = left / right walls
# Functional "False" = top / bottom walls

# TRYOUT:
#top = Border(-470, 392, 930, False)
#right = Border(460, 392, 775, True)
#left = Border(-470, 392, 775, True)
#bottom = Border(-470, -385, 930, False)
