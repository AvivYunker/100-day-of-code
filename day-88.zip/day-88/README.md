# Day 88 - To Do Agenda App

## Concepts Practised
- Create a Web Server with Flask
- Use the Command Line on Windows and Mac
- `__name__` and `__main__` : Special Attributes built into Python
- Python Decorator Functions and the `@` Syntax
- Flask URL Paths and the Flask Debugger
- Rendering HTML Elements with Flask
- Use Python Decorators to Style HTML Tags
- Decorators with `*args` and `**kwargs`
Create a Python Decorator

## Run Locally:

1. CD into the project folder: `./todo-app`

2. Run `pip install -r requirements.txt` to install the dependencies

3. Run the flask app with `python main.py`

## To Do App Demo
<img width="955" alt="day88" src="https://user-images.githubusercontent.com/98851253/170607934-975540fc-22c3-44aa-8118-7f42af2ee252.png">
