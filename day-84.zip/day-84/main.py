def insert(position, char):
    try:
        if (int(position) <= 0 or int(position) >= 10):
            return False
        else:
            if (position == board[0][0]):
                board[0][0] = str(char)
                return True
            elif (position == board[0][1]):
                board[0][1] = str(char)
                return True
            elif (position == board[0][2]):
                board[0][2] = str(char)
                return True
            elif (position == board[1][0]):
                board[1][0] = str(char)
                return True
            elif (position == board[1][1]):
                board[1][1] = str(char)
                return True
            elif (position == board[1][2]):
                board[1][2] = str(char)
                return True
            elif (position == board[2][0]):
                board[2][0] = str(char)
                return True
            elif (position == board[2][1]):
                board[2][1] = str(char)
                return True
            elif (position == board[2][2]):
                board[2][2] = str(char)
                return True
            else:
                return False
    except:
        return False

def check_game_over():
    if (board[0][0] == board[0][1] and board[0][1] == board[0][2] and board[0][2] != '_'):
        return board[0][0]
    elif (board[1][0] == board[1][1] and board[1][1] == board[1][2] and board[1][2] != '_'):
        return board[1][0]
    elif (board[2][0] == board[2][1] and board[2][1] == board[2][2] and board[2][2] != '_'):
        return board[2][0]
        
    elif (board[0][0] == board[1][0] and board[1][0] == board[2][0] and board[2][0] != '_'):
        return board[0][0]
    elif (board[0][1] == board[1][1] and board[1][1] == board[2][1] and board[1][2] != '_'):
        return board[1][0]
    elif (board[0][2] == board[1][2] and board[1][2] == board[2][2] and board[2][2] != '_'):
        return board[2][0]
        
    elif (board[0][0] == board[1][1] and board[1][1] == board[2][2] and board[2][2] != '_'):
        return board[0][0]
    elif (board[2][0] == board[1][1] and board[1][1] == board[0][2] and board[0][2] != '_'):
        return board[2][0]
    else:
        return False

def print_board():
    print("")
    for cnt1 in range(0, len(board), 1):
        print(f"{board[cnt1][0]} | {board[cnt1][1]} | {board[cnt1][2]}")
        if (cnt1 != len(board) - 1):
            print("---------")
    print("")

def prepare_board():
    num = int(1)
    for cnt1 in range(0, 3, 1):
        for cnt2 in range(0, 3, 1):
            board[cnt1].append(str(num))
            num += 1

board = [[],[],[]]
prepare_board()
game_over = False
turn = 'X'
while (game_over == False):
    print_board()
    if (turn == 'X'):
        position = input("Place an 'X' (num-on-board): ")
        placed = insert(position, 'X')
        while (placed == False):
            print_board()
            print("Sorry, this position is invalid.")
            position = input("Place an 'X' (num-on-board): ")
            placed = insert(position, 'X')
        turn = 'O'
    else:
        position = input("Place an 'O' (num-on-board): ")
        print_board()
        placed = insert(position, 'O')
        turn = 'O'
        while (placed == False):
            position = input("Place an 'O' (num-on-board): ")
            print("Sorry, this position is invalid.")
            placed = insert(position, 'O')
        turn = 'X'
    game_over = check_game_over()

print_board()
print(f"The winner is: {game_over}!")
