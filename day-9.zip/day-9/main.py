from replit import clear
#HINT: You can call clear() to clear the output in the console.
logo = '''
                         ___________
                         \         /
                          )_______(
                          |"""""""|_.-._,.---------.,_.-._
                          |       | | |               | | ''-.
                          |       |_| |_             _| |_..-'
                          |_______| '-' `'---------'` '-'
                          )"""""""(
                         /_________\\
                       .-------------.
                      /_______________\\
'''

bids = {}


def add_bid(name, bid, bids):
  bids[name] = float(bid)

def determine_winner(bids):
  name_highest = ""
  bid_highest = int(-1)
  for name in bids:
    if (bids[name] > bid_highest):
      bid_highest = bids[name]
      name_highest = name
  print(f"The winner is {name_highest} with a bid of ${bid_highest}.")

finished = False
print(logo)
while (finished == False):
  name = input("What is your name?: ")
  bid = input("What is your bid?: $")
  add_bid(name, bid, bids)
  finished = input("Are there any other bidders? Type 'yes or 'no'.\n").lower()
  if (finished != 'yes' and finished != 'no'):
    print("Sorry, your decision wasn't clear.")
    finished = input("Are there any other bidders? Type 'yes or 'no'.\n").lower()
  if (finished == 'yes'):
    finished = False
  else:
    finished = True
  clear()

determine_winner(bids)
