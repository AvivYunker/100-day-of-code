logo = """
.------.            _     _            _    _            _
|A_  _ |.          | |   | |          | |  (_)          | |
|( \/ ).-----.     | |__ | | __ _  ___| | ___  __ _  ___| | __
| \  /|K /\  |     | '_ \| |/ _` |/ __| |/ / |/ _` |/ __| |/ /
|  \/ | /  \ |     | |_) | | (_| | (__|   <| | (_| | (__|   <
`-----| \  / |     |_.__/|_|\__,_|\___|_|\_\ |\__,_|\___|_|\_\\
      |  \/ K|                            _/ |
      `------'                           |__/
"""
import random
# A = 1 or 11
card_choices = ['A',2,3,4,5,6,7,8,9,10,'J','Q','K']

def add_cards(deck, amount):
    for cnt in range(0, amount, 1):
        deck.append(random.choice(card_choices))

def calc_score(deck):
    res = int(0)
    A_cnt = int(0)
    for card in deck:
        if (card == 'A'):
            A_cnt += 1
        elif (card == 'J' or card == 'Q' or card == 'K'):
            res += 10
        else:
            res += int(card)
    while (A_cnt > 0):
        if (res + A_cnt <= 21):
            res += 11
        else:
            res += 1
        A_cnt -= 1
    return res

def check_game_over(my_cards, computer_cards):
    my_sums = calc_score(my_cards)
    computer_sums = calc_score(computer_cards)
    #You went over. You lose 😭
    #You lose 😤
    #Opponent went over. You win 😁
    #You win 😃
    if (my_sums > 21 and computer_sums <= 21):
        print(f"Your final hand: {my_cards}, final score: {my_sums}")
        print(f"Computer's final hand: {computer_cards}, final score: {computer_sums}")
        print("You went over. You lose 😭")
        return True
    elif (computer_sums > 21 and my_sums <= 21):
        print(f"Your final hand: {my_cards}, final score: {my_sums}")
        print(f"Computer's final hand: {computer_cards}, final score: {computer_sums}")
        print("Opponent went over. You win 😁")
        return True
    elif (my_sums > 21 and computer_sums > 21):
        print(f"Your final hand: {my_cards}, final score: {my_sums}")
        print(f"Computer's final hand: {computer_cards}, final score: {computer_sums}")
        print("It's a draw... 😶")
        return True
    else:
        return False



def im_finishing(my_cards, computer_cards):
    my_sums = calc_score(my_cards)
    computer_sums = calc_score(computer_cards)
    print(f"Your final hand: {my_cards}, final score: {my_sums}")
    print(f"Computer's final hand: {computer_cards}, final score: {computer_sums}")
    if (computer_sums > 21):
        print("Opponent went over. You win 😁")
    elif (my_sums > 21):
        print("You went over. You lose 😭")
    else:
        if (my_sums > computer_sums):
            print("You win 😃")
        elif (my_sums < computer_sums):
            print("You lose 😤")
        else:
            print("It's a draw... 😶")

play = 'y'
while (play == 'y'):
    play = input("Do you want to play a game of Blackjack? Type 'y' or 'n': ").lower()
    while (play != 'y' and play != 'n'):
        print("Sorry, your decision wasn't clear.")
        play = input("Do you want to play a game of Blackjack? Type 'y' or 'n': ").lower()
    if (play == 'y'):
        game_over = False
        my_cards = []
        computer_cards = []
        add_cards(my_cards, 2)
        add_cards(computer_cards, 2)
        print(logo)
        while (game_over == False):
            print("")
            print(f"Your cards: {my_cards}, current score: {calc_score(my_cards)}")
            print(f"Computer's first card: {computer_cards[0]}")
            choice = input("Type 'y' to get another card, type 'n' to pass: ").lower()
            while (choice != 'y' and choice != 'n'):
                print("Sorry, your decision wasn't clear.")
                choice = input("Type 'y' to get another card, type 'n' to pass: ").lower()
            if (calc_score(computer_cards) < 17):
                add_cards(computer_cards, 1)
            if (choice == 'y'):
                add_cards(my_cards, 1)
                game_over = check_game_over(my_cards, computer_cards)
            elif (choice == 'n'):
                game_over = im_finishing(my_cards, computer_cards)
            else:
                game_over = check_game_over(my_cards, computer_cards)
    else:
        print("See you later!")

#Type 'y' to get another card, type 'n' to pass: y
#Your final hand: [10, 2, 'J'], final score: 22
#Computer's final hand: [5, 'J', 7], final score: 22
#It's a draw... 😶
