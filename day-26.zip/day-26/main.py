import pandas
file = pandas.read_csv('nato_phonetic_alphabet.csv')

# WORKS
letters = file['letter'].tolist()
#print(letters)

# WORKS
codes = file['code'].tolist()
#print(codes)

# WORKS
phonetic_dict = {}
for cnt in range(0, len(letters), 1):
    phonetic_dict[letters[cnt]] = codes[cnt]
#print(phonetic_dict)


word = input("Enter a word: ").upper()
results = [phonetic_dict[letter] for letter in word]
print(results)
