from selenium import webdriver
from selenium.webdriver.common.by import By
import time

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options



driver = webdriver.Chrome()

driver.get("https://tinder.com/")
driver.maximize_window()
time.sleep(3)

accept_button = driver.find_element(By.XPATH, "//div[text()='I accept']/../..")
accept_button.click()

log_in_button = driver.find_element(By.XPATH, "//div[text()='Log in']/../..")
log_in_button.click()
time.sleep(1)

log_in_with_phone_number = driver.find_element(By.XPATH, "//div[text()='Log in with phone number']")
log_in_with_phone_number.click()
time.sleep(200)

phone_number_input = driver.find_element(By.XPATH, "//input[@name='phone_number']")
phone_number_input.send_keys("535284358")

continue_button = driver.find_element(By.XPATH, "//div[text()='Continue']")
continue_button.click()

time.sleep(50)

allow_location_button = driver.find_element(By.XPATH, "//div[text()='Allow']")
allow_location_button.click()

time.sleep(2)

chrome_options = Options()
chrome_options.add_argument("--use-fake-ui-for-media-stream")
driver = webdriver.Chrome(executable_path="path/to/chromedriver", chrome_options=chrome_options)

time.sleep(2)

disable_notifications_button = driver.find_element(By.XPATH, "//div[text()='Not interested']")
disable_notifications_button.click()

swipe_left_button = driver.find_element(By.XPATH, "(//button[@type='button'][@draggable='false'])[2]")

while (True):
    swipe_left_button.click()
    time.sleep(1)
