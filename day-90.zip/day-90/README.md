## Day 90 Course Assignment: Convert PDF to Audiobook

_Write a Python script that takes a PDF file and converts it to speech_

## Concepts Practised

- Creating Windows and Labels with Tkinter
- Use grid() to complete the User Interface
- Use tkinter filedialog to select a PDF file
- Use gTTS to convert text to speech

## Text to Speech

<img width="416" alt="day90(1)" src="https://user-images.githubusercontent.com/98851253/171080875-f33d41a7-dec0-4c58-a7bc-7e49bf03c60c.png">
<img width="417" alt="day90(2)" src="https://user-images.githubusercontent.com/98851253/171080877-a3472ab2-cc94-4847-9bf8-085331ea641e.png">
<img width="257" alt="day90(3)" src="https://user-images.githubusercontent.com/98851253/171080873-2f2983d6-0763-4647-ab20-095b3281cc80.png">
