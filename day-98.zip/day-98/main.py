from selenium import webdriver
from selenium.webdriver.common.by import By
import time

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


driver = webdriver.Chrome()

driver.get("https://10fastfingers.com/")
driver.maximize_window()
time.sleep(3)

allow_all = driver.find_element(By.XPATH, "//button[text()='Allow all']")
allow_all.click()
time.sleep(0.5)

start_typing_test = driver.find_element(By.XPATH, "//a[@id='typing-test']")
start_typing_test.click()
time.sleep(3)

input_word = driver.find_element(By.XPATH, "//input[@id='inputfield']")
all_words = driver.find_elements(By.XPATH, "//div[@id='row1']//span")

for word in all_words:
    input_word.send_keys(word.text + " ")
    time.sleep(0.01)
input_word.clear()

time.sleep(37)

WebDriverWait(driver, 10).until(EC.alert_is_present())
driver.switch_to.alert.accept()
time.sleep(6)

result = driver.find_element(By.XPATH, "//h3[text()='Result ']")

if (result.text == "Result Screenshot"):
    print("Test passed!")
else:
    print("Test failed.")

driver.quit()
