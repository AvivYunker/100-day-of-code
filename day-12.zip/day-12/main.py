#Number Guessing Game Objectives:

# Include an ASCII art logo.
# Allow the player to submit a guess for a number between 1 and 100.
# Check user's guess against actual answer. Print "Too high." or "Too low." depending on the user's answer. 
# If they got the answer correct, show the actual answer to the player.
# Track the number of turns remaining.
# If they run out of turns, provide feedback to the player. 
# Include two different difficulty levels (e.g., 10 guesses in easy mode, only 5 guesses in hard mode).


logo = """
 _____  _     _____   _      _     _      ____  _____ ____    _____ _     _____ ____  ____  _  _      _____   _____ ____  _      _____
/__ __\/ \ /|/  __/  / \  /|/ \ /\/ \__/|/  _ \/  __//  __\  /  __// \ /\/  __// ___\/ ___\/ \/ \  /|/  __/  /  __//  _ \/ \__/|/  __/
  / \  | |_|||  \    | |\ ||| | ||| |\/||| | //|  \  |  \/|  | |  _| | |||  \  |    \|    \| || |\ ||| |  _  | |  _| / \|| |\/|||  \  
  | |  | | |||  /_   | | \||| \_/|| |  ||| |_\\|  /_ |    /  | |_//| \_/||  /_ \___ |\___ || || | \||| |_//  | |_//| |-||| |  |||  /_ 
  \_/  \_/ \|\____\  \_/  \|\____/\_/  \|\____/\____\\_/\_\  \____\\____/\____\\____/\____/\_/\_/  \|\____\  \____\\_/ \|\_/  \|\____\
                                                                                                                                      
"""
import random
print(logo)
print("Welcome to the Number Guessing Game!")
print("I'm thinking of a number between 1 and 100.")
rndm = random.randint(1,100)
#print(rndm)
remaining = input("Choose a difficulty. Type 'easy' or 'hard': ").lower()
while (remaining != 'easy' and remaining != 'hard'):
    print("Sorry, your decision wasn't clear.")
    remaining = input("Choose a difficulty. Type 'easy' or 'hard': ").lower()
if (remaining == 'easy'):
    remaining = int(10)
else:
    remaining = int(5)

guess = int(-1)
while (remaining > 0 and guess != rndm):
    guess = int(input("Make a guess: "))
    if (guess != rndm):
        remaining -= 1
        if (guess > rndm):
            print(f"Too high.\nGuess again.\nYou have {remaining} attempts remaining to guess the number.")
        else:
            print(f"Too low.\nGuess again.\nYou have {remaining} attempts remaining to guess the number.")
            

if (guess == rndm):
    print(f"You got it! The answer was {rndm}.")
else:
    print("You've run out of guesses, you lose.")
