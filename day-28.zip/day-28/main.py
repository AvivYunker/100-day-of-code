import tkinter

window = tkinter.Tk()
window.title("Mile to Km Converter")
window.minsize(width=250, height=50)

def calculate():
    miles = float(input_field.get())
    kilometers = round(miles * 1.609344, 2)
    actualvalue_label["text"] = kilometers
    #print("I got clicked!")

# Entry
input_field = tkinter.Entry(width=10)
input_field.place(x=100, y=30)
print(input_field.get())

# Label ("Miles")
miles_label = tkinter.Label(text="Miles", font=("Arial", 12))
miles_label.place(x=200, y=30)

# Label ("is equals to")
isequalto_label = tkinter.Label(text="is equal to", font=("Arial", 12))
isequalto_label.place(x=10, y=60)

# Label (actual value)
actualvalue_label = tkinter.Label(text="0", font=("Arial", 12))
actualvalue_label.place(x=125, y=60)

# Label ("Km")
km_label = tkinter.Label(text="km", font=("Arial", 12))
km_label.place(x=200, y=60)

# Button ("Calculate")
button = tkinter.Button(text="Click Me", command=calculate)
button.place(x=100, y=90)

window.mainloop()
