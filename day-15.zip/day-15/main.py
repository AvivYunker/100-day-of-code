# Espresso - 50ml water, 18g coffee
# Latte - 200ml water, 24g coffee, 150ml milk
# Cappuccino - 250ml water, 24g coffee, 100ml milk

# initial resources - 300ml water, 200ml milk, 100g coffee

# coins - penny (1 cent, 0.01$), nickel (5 cents, 0.05$) dime (10 cents, 0.1$) quarter (25 cents, 0.25$)

# program requirements:
# print report:
    # Water: ___ml
    # Milk: ___ml
    # Coffee: ___g
    # Money: $___g

# check resources
    # Sorry there's not enough _____, _____.

# Process coins
# Sorry. That's not enough money. Money refunded.
# Here is $___ in change.

# Make the coffee and deduct the resources

MENU = {
    "espresso": {
        "ingredients": {
            "water": 50,
            "milk": 0,
            "coffee": 18,
        },
        "cost": 1.5,
    },
    "latte": {
        "ingredients": {
            "water": 200,
            "milk": 150,
            "coffee": 24,
        },
        "cost": 2.5,
    },
    "cappuccino": {
        "ingredients": {
            "water": 250,
            "milk": 100,
            "coffee": 24,
        },
        "cost": 3.0,
    }
}

resources = {
    "water": 300,
    "milk": 200,
    "coffee": 100,
    "money": 0,
}

# coins - penny (1 cent, 0.01$), nickel (5 cents, 0.05$) dime (10 cents, 0.1$) quarter (25 cents, 0.25$)
def check_money(quarters, dimes, nickles, pennies, choice):
    if (quarters * 0.25 + dimes * 0.1 + nickles * 0.05 + pennies * 0.01 > MENU[choice]["cost"]):
        return True
    else:
        return False

def calc_missing_money(quarters, dimes, nickles, pennies, choice):
    return round(MENU[choice]["cost"] - quarters * 0.25 + dimes * 0.1 + nickles * 0.05 + pennies * 0.01, 2)

def calc_missing_resources(choice):
    missing = ""
    print('MENU[choice]["ingredients"]["water"]' + str(MENU[choice]["ingredients"]["water"]))
    print('MENU[choice]["ingredients"]["milk"]' + str(MENU[choice]["ingredients"]["milk"]))
    print('MENU[choice]["ingredients"]["coffee"]' + str(MENU[choice]["ingredients"]["coffee"]))
    print('resources["water"]' + str(resources["water"]))
    print('resources["milk"]' + str(resources["milk"]))
    print('resources["coffee"]' + str(resources["coffee"]))
    
    if (MENU[choice]["ingredients"]["water"] > resources["water"]):
        missing += "water: " + str(MENU[choice]["ingredients"]["water"] - resources["water"]) + ", "
    if (MENU[choice]["ingredients"]["milk"] > resources["milk"]):
        missing += "milk: " + str(MENU[choice]["ingredients"]["milk"] - resources["milk"]) + ", "
    if (MENU[choice]["ingredients"]["coffee"] > resources["coffee"]):
        missing += "coffee: " + str(MENU[choice]["ingredients"]["coffee"] - resources["coffee"]) + ", "
    missing = missing[:-2]
    missing += '.'
    return missing

def calc_change(quarters, dimes, nickles, pennies, choice):
    return quarters * 0.25 + dimes * 0.1 + nickles * 0.05 + pennies * 0.01 - MENU[choice]["cost"]

def check_resources(choice):
    if (
        resources["water"] >= MENU[choice]["ingredients"]["water"] and
        resources["milk"] >= MENU[choice]["ingredients"]["milk"] and
        resources["coffee"] >= MENU[choice]["ingredients"]["coffee"]
    ):
        return True
    else:
        return False

def deplete_resources(choice):
    resources["water"] -= MENU[choice]["ingredients"]["water"]
    resources["milk"] -= MENU[choice]["ingredients"]["milk"]
    resources["coffee"] -= MENU[choice]["ingredients"]["coffee"]

def add_coins(quarters, dimes, nickles, pennies):
    resources['money'] += MENU[choice]['cost']

def print_report():
    print(f"Water: {resources['water']}ml\nMilk: {resources['milk']}ml\nCoffee: {resources['coffee']}g\nMoney: ${resources['money']}")

def refill_resources(water, milk, coffee):
    resources["water"] += water
    resources["milk"] += milk
    resources["coffee"] += coffee
    print("Finished filling resources!")

finished = False
while (finished == False):
    choice = input("What would you like? (espresso / latte / cappuccino): ").lower()
    if (choice == "espresso" or choice == "latte" or choice == "cappuccino"):
        print("Please insert coins.")
        quarters = int(input("How many quarters?: "))
        dimes = int(input("How many dimes?: "))
        nickles = int(input("How many nickles?: "))
        pennies = int(input("How many pennies?: "))
        suff_money = check_money(quarters, dimes, nickles, pennies, choice)
        if (suff_money == True):
            suff_resources = check_resources(choice)
            if (suff_resources == True):
                deplete_resources(choice)
                add_coins(quarters, dimes, nickles, pennies)
                print(f"Here is ${calc_change(quarters, dimes, nickles, pennies, choice)} in change.")
                print(f"Here is your {choice} ☕. Enjoy!")
            else:
                print("suff_resources" + str(suff_resources))
                print(f"You are missing {calc_missing_resources(choice)}")
        else:
            print(f"You are missing ~${calc_missing_money(quarters, dimes, nickles, pennies, choice)}")
    elif (choice == "report"): # print report
        print_report()
    elif (choice == "refill"): # refill resources
        water = int(input("Enter amount of water: "))
        milk = int(input("Enter amount of milk: "))
        coffee = int(input("Enter amount of coffee: "))
        refill_resources(water, milk, coffee)
    elif (choice == "off"):
        finished = True
        print("Have a nice day.")
    else:
        print("Sorry. Your decision wasn't clear.")
